import os
from flask import Flask, render_template, request, redirect, session, url_for, g, send_file, jsonify, flash
from functools import wraps
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import pymysql
import sqlite3
import os
import uuid
import mimetypes
import secrets
import smtplib
import ssl
from email.message import EmailMessage

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', uuid.uuid4().hex)
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH', str(10 * 1024 * 1024)))

DB_TYPE = os.getenv('DB_TYPE', 'sqlite').lower()
USE_MYSQL = DB_TYPE == 'mysql'

MYSQL_HOST = os.getenv('MYSQL_HOST', 'localhost')
MYSQL_PORT = int(os.getenv('MYSQL_PORT', 3306))
MYSQL_USER = os.getenv('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '')
MYSQL_DATABASE = os.getenv('MYSQL_DATABASE', 'smartcampus')

DATABASE = os.getenv('SQLITE_DATABASE', os.path.join(app.root_path, 'users.db'))

UPLOAD_DIR = os.getenv('UPLOAD_DIR', os.path.join(app.root_path, 'instance', 'uploads'))
MAX_FILE_SIZE = 10 * 1024 * 1024
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt', 'jpg', 'jpeg', 'png', 'gif', 'zip'}


def env_bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {'1', 'true', 'yes', 'on'}


def env_int(name, default):
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


SMTP_HOST = os.getenv('SMTP_HOST', '')
SMTP_PORT = env_int('SMTP_PORT', 587)
SMTP_USERNAME = os.getenv('SMTP_USERNAME', os.getenv('SMTP_USER', ''))
SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
SMTP_FROM = os.getenv('SMTP_FROM', SMTP_USERNAME or 'no-reply@smartcampus.example')
SMTP_REPLY_TO = os.getenv('SMTP_REPLY_TO', SMTP_FROM)
SMTP_USE_TLS = env_bool('SMTP_USE_TLS', True)
SMTP_USE_SSL = env_bool('SMTP_USE_SSL', False)
SMTP_TIMEOUT = env_int('SMTP_TIMEOUT', 20)
SMTP_REQUIRE_AUTH = env_bool('SMTP_REQUIRE_AUTH', True)
APP_BASE_URL = os.getenv('APP_BASE_URL', 'http://127.0.0.1:5000').rstrip('/')

INITIAL_USERS = {
    'admin': {
        'password': os.getenv('DEFAULT_ADMIN_PASSWORD', 'admin123'),
        'role': 'admin',
        'email': 'admin@smartcampus.example',
        'phone': '70000001',
        'address': 'Admin Office'
    },
    'it': {
        'password': os.getenv('DEFAULT_IT_PASSWORD', 'it123'),
        'role': 'it',
        'email': 'it@smartcampus.example',
        'phone': '70000002',
        'address': 'IT Office'
    },
    'teacher': {
        'password': os.getenv('DEFAULT_TEACHER_PASSWORD', 'teacher123'),
        'role': 'teacher',
        'email': 'teacher@smartcampus.example',
        'phone': '70000003',
        'address': 'Teacher Office'
    },
    'student': {
        'password': os.getenv('DEFAULT_STUDENT_PASSWORD', 'student123'),
        'role': 'user',
        'email': 'student@smartcampus.example',
        'phone': '70000004',
        'address': 'Student Dorm'
    },
    'user': {
        'password': os.getenv('DEFAULT_USER_PASSWORD', 'user123'),
        'role': 'user',
        'email': 'user@example.com',
        'phone': '70000005',
        'address': 'Campus'
    }
}

@app.context_processor
def inject_current_year():
    data = {'current_year': datetime.now().year}
    if session.get('user'):
        try:
            row = query_db('SELECT COUNT(*) AS c FROM notifications WHERE recipient = %s AND is_read = %s', (session.get('user'), 0), one=True)
            data['notification_count'] = int(row['c']) if row else 0
        except Exception:
            data['notification_count'] = 0
    return data


def translate_query(query):
    return query if USE_MYSQL else query.replace('%s', '?')


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        if USE_MYSQL:
            db = g._database = pymysql.connect(
                host=MYSQL_HOST,
                port=MYSQL_PORT,
                user=MYSQL_USER,
                password=MYSQL_PASSWORD,
                database=MYSQL_DATABASE,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor,
                autocommit=False
            )
        else:
            db = g._database = sqlite3.connect(DATABASE)
            db.row_factory = sqlite3.Row
    return db


def query_db(query, params=None, one=False):
    db = get_db()
    if USE_MYSQL:
        with db.cursor() as cursor:
            cursor.execute(query, params or ())
            return cursor.fetchone() if one else cursor.fetchall()
    else:
        cursor = db.cursor()
        try:
            cursor.execute(translate_query(query), params or ())
            return cursor.fetchone() if one else cursor.fetchall()
        finally:
            cursor.close()


def execute_db(query, params=None, commit=False, return_lastrowid=False):
    db = get_db()
    if USE_MYSQL:
        with db.cursor() as cursor:
            cursor.execute(query, params or ())
            if commit:
                db.commit()
            if return_lastrowid:
                return cursor.lastrowid
            return None
    else:
        cursor = db.cursor()
        try:
            cursor.execute(translate_query(query), params or ())
            if commit:
                db.commit()
            if return_lastrowid:
                return cursor.lastrowid
            return None
        finally:
            cursor.close()



def seed_demo_test_data():
    """Create demo accounts and sample dashboard data for testing."""
    try:
        now = datetime.now().strftime('%Y-%m-%d %H:%M')

        # Demo users
        demo_users = [
            ('admin', 'admin123', 'admin', 'admin@smartcampus.example', '70000001', 'Admin Office'),
            ('it', 'it123', 'it', 'it@smartcampus.example', '70000002', 'IT Office'),
            ('teacher', 'teacher123', 'teacher', 'teacher@smartcampus.example', '70000003', 'Teacher Office'),
            ('student', 'student123', 'user', 'student@smartcampus.example', '70000004', 'Student Dorm'),
            ('user', 'user123', 'user', 'user@example.com', '70000005', 'Campus'),
        ]

        for username, password, role, email, phone, address in demo_users:
            existing = query_db('SELECT username FROM users WHERE username = %s', (username,), one=True)
            if not existing:
                execute_db(
                    'INSERT INTO users (username, password, role, email, phone, address, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
                    (username, generate_password_hash(password), role, email, phone, address, now),
                    commit=True
                )

        # Demo pending requests
        try:
            pending = query_db('SELECT username FROM pending_users WHERE username = %s', ('pendingstudent',), one=True)
            if not pending:
                execute_db(
                    'INSERT INTO pending_users (username, password, email, phone, address, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
                    ('pendingstudent', generate_password_hash('pending123'), 'pending@student.example', '70000006', 'Pending Address', now),
                    commit=True
                )
        except Exception:
            pass

        # Demo tickets/service requests
        demo_tickets = [
            ('student', 'Wi-Fi not working in Library', 'The campus Wi-Fi disconnects every few minutes near the library.', 'IT Support', 'High', 'Open', 'it', 'Library Floor 2'),
            ('student', 'Projector problem in Room 204', 'The projector does not display HDMI input.', 'Classroom Support', 'Normal', 'In Progress', 'it', 'Building A Room 204'),
            ('teacher', 'Need lab equipment for networking class', 'Requesting extra Ethernet cables and one switch for the lab.', 'Equipment Request', 'Normal', 'Open', 'it', 'Networking Lab'),
            ('user', 'Account access issue', 'Cannot access the student portal from my laptop.', 'Account Access', 'High', 'Resolved', 'admin', 'Online'),
        ]

        for username, subject, description, category, priority, status, assigned_to, location in demo_tickets:
            exists = query_db('SELECT id FROM tickets WHERE username = %s AND subject = %s', (username, subject), one=True)
            if not exists:
                try:
                    tid = create_ticket(username, subject, description, category, priority, '', location)
                    execute_db('UPDATE tickets SET status = %s, assigned_to = %s WHERE id = %s', (status, assigned_to, tid), commit=True)
                except Exception:
                    execute_db(
                        'INSERT INTO tickets (username, subject, description, extra_message, category, status, priority, assigned_to, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)',
                        (username, subject, description, '', category, status, priority, assigned_to, now),
                        commit=True
                    )

        # Demo messages
        try:
            demo_messages = [
                ('teacher', 'student', 'Grade Published', 'Your Networking Fundamentals grade has been published.'),
                ('student', 'teacher', 'Question about assignment', 'Can you explain the database assignment requirements?'),
                ('admin', 'student', 'Welcome', 'Your Smart Campus account is ready for testing.'),
                ('it', 'teacher', 'Support Ticket Update', 'Your classroom support request is assigned to IT.'),
            ]
            for sender, recipient, subject, body in demo_messages:
                exists = query_db('SELECT id FROM messages WHERE sender = %s AND recipient = %s AND subject = %s', (sender, recipient, subject), one=True)
                if not exists:
                    create_message(sender, recipient, subject, body)
        except Exception:
            pass

        # Demo grades
        try:
            demo_grades = [
                ('student', 'teacher', 'Networking Fundamentals', 'A', 'Excellent practical lab work.'),
                ('student', 'teacher', 'Database Systems', 'B+', 'Good SQL performance.'),
                ('user', 'teacher', 'Cybersecurity Basics', 'A-', 'Strong security awareness.'),
            ]
            for student_username, teacher_username, course, grade, comments in demo_grades:
                exists = query_db('SELECT id FROM grades WHERE student_username = %s AND course = %s', (student_username, course), one=True)
                if not exists:
                    execute_db(
                        'INSERT INTO grades (student_username, teacher_username, course, grade, comments, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
                        (student_username, teacher_username, course, grade, comments, now),
                        commit=True
                    )
        except Exception:
            pass


        # Demo attendance
        try:
            demo_attendance = [
                ('student', 'teacher', 'Networking Fundamentals', '2026-05-19', 'Present', 'QR check-in'),
                ('student', 'teacher', 'Database Systems', '2026-05-18', 'Late', '10 minutes late'),
                ('user', 'teacher', 'Cybersecurity Basics', '2026-05-17', 'Present', 'Manual check-in'),
            ]
            for student_username, teacher_username, course, attendance_date, status, note in demo_attendance:
                exists = query_db('SELECT id FROM attendance WHERE student_username = %s AND course = %s AND attendance_date = %s', (student_username, course, attendance_date), one=True)
                if not exists:
                    execute_db(
                        'INSERT INTO attendance (student_username, teacher_username, course, attendance_date, status, note, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
                        (student_username, teacher_username, course, attendance_date, status, note, now),
                        commit=True
                    )
        except Exception:
            pass

        # Demo appointments
        try:
            demo_appts = [
                ('student', 'IT Support', '2026-05-25 10:00', 'Laptop network setup help'),
                ('teacher', 'Administration', '2026-05-26 13:30', 'Classroom booking discussion'),
            ]
            for username, department, appointment_time, reason in demo_appts:
                exists = query_db('SELECT id FROM appointments WHERE username = %s AND reason = %s', (username, reason), one=True)
                if not exists:
                    create_user_appointment(username, department, appointment_time, reason)
        except Exception:
            pass

        # Demo notifications
        try:
            demo_notifications = [
                ('student', 'Welcome to Smart Campus', 'Your dashboard now includes tickets, messages, grades and attendance.'),
                ('teacher', 'Teacher Dashboard Ready', 'You can test grade, message and attendance panels.'),
                ('admin', 'Demo Data Created', 'Test accounts and sample data are available.'),
            ]
            for recipient, title, body in demo_notifications:
                exists = query_db('SELECT id FROM notifications WHERE recipient = %s AND title = %s', (recipient, title), one=True)
                if not exists:
                    execute_db(
                        'INSERT INTO notifications (recipient, title, body, is_read, created_at) VALUES (%s, %s, %s, %s, %s)',
                        (recipient, title, body, 0, now),
                        commit=True
                    )
        except Exception:
            pass

        log_activity('system', 'seed_demo_test_data', 'Demo accounts, tickets, grades and messages created')
    except Exception as exc:
        print('Demo seed skipped:', exc)

@app.teardown_appcontext
def close_connection(exception=None):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


def init_db():
    if USE_MYSQL:
        admin_db = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True
        )
        with admin_db.cursor() as cursor:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{MYSQL_DATABASE}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
        admin_db.close()

        db = get_db()
        with db.cursor() as cursor:
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    role VARCHAR(50) NOT NULL,
                    email VARCHAR(255),
                    phone VARCHAR(100),
                    address VARCHAR(255),
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS tickets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) NOT NULL,
                    subject VARCHAR(255) NOT NULL,
                    description TEXT NOT NULL,
                    extra_message TEXT,
                    category VARCHAR(100) NOT NULL,
                    status VARCHAR(50) NOT NULL,
                    priority VARCHAR(50) NOT NULL,
                    assigned_to VARCHAR(150),
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_comments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ticket_id INT NOT NULL,
                    author VARCHAR(150) NOT NULL,
                    body TEXT NOT NULL,
                    created_at VARCHAR(19) NOT NULL,
                    FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS grades (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_username VARCHAR(150) NOT NULL,
                    teacher_username VARCHAR(150) NOT NULL,
                    course VARCHAR(150) NOT NULL,
                    grade VARCHAR(50) NOT NULL,
                    comments TEXT,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attachments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ticket_id INT NOT NULL,
                    filename VARCHAR(255) NOT NULL,
                    file_path VARCHAR(500) NOT NULL,
                    uploaded_by VARCHAR(150) NOT NULL,
                    created_at VARCHAR(19) NOT NULL,
                    FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS comment_attachments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    comment_id INT NOT NULL,
                    filename VARCHAR(255) NOT NULL,
                    file_path VARCHAR(500) NOT NULL,
                    uploaded_by VARCHAR(150) NOT NULL,
                    created_at VARCHAR(19) NOT NULL,
                    FOREIGN KEY(comment_id) REFERENCES ticket_comments(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS pending_users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) UNIQUE NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    phone VARCHAR(100),
                    address VARCHAR(255),
                    password VARCHAR(255) NOT NULL,
                    role VARCHAR(50) NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS messages (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    sender VARCHAR(150) NOT NULL,
                    recipient VARCHAR(150) NOT NULL,
                    subject VARCHAR(255) NOT NULL,
                    body TEXT NOT NULL,
                    is_read TINYINT(1) NOT NULL DEFAULT 0,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS activity_log (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    time VARCHAR(19) NOT NULL,
                    actor VARCHAR(150) NOT NULL,
                    action VARCHAR(100) NOT NULL,
                    details TEXT
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS knowledge_articles (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    category VARCHAR(100) NOT NULL,
                    body TEXT NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS status_updates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    service VARCHAR(150) NOT NULL,
                    status VARCHAR(50) NOT NULL,
                    message TEXT,
                    updated_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS ticket_votes (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    ticket_id INT NOT NULL,
                    username VARCHAR(150) NOT NULL,
                    created_at VARCHAR(19) NOT NULL,
                    UNIQUE KEY unique_ticket_vote (ticket_id, username),
                    FOREIGN KEY(ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS inventory_items (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    asset_tag VARCHAR(150) UNIQUE NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    category VARCHAR(100) NOT NULL,
                    location VARCHAR(255),
                    status VARCHAR(50) NOT NULL,
                    assigned_to VARCHAR(150),
                    notes TEXT,
                    updated_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS appointments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) NOT NULL,
                    department VARCHAR(150) NOT NULL,
                    appointment_time VARCHAR(50) NOT NULL,
                    reason TEXT NOT NULL,
                    status VARCHAR(50) NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS calendar_events (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    event_date VARCHAR(10) NOT NULL,
                    event_time VARCHAR(5),
                    location VARCHAR(255),
                    category VARCHAR(100) NOT NULL,
                    description TEXT,
                    created_by VARCHAR(150) NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS password_reset_tokens (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    token VARCHAR(255) UNIQUE NOT NULL,
                    expires_at VARCHAR(19) NOT NULL,
                    used TINYINT(1) NOT NULL DEFAULT 0,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS notifications (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    recipient VARCHAR(150) NOT NULL,
                    title VARCHAR(255) NOT NULL,
                    body TEXT NOT NULL,
                    link VARCHAR(500),
                    is_read TINYINT(1) NOT NULL DEFAULT 0,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS announcements (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    body TEXT NOT NULL,
                    priority VARCHAR(50) NOT NULL,
                    created_by VARCHAR(150) NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS emergency_reports (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) NOT NULL,
                    emergency_type VARCHAR(100) NOT NULL,
                    location VARCHAR(255) NOT NULL,
                    description TEXT,
                    status VARCHAR(50) NOT NULL,
                    created_at VARCHAR(19) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS attendance_records (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    username VARCHAR(150) NOT NULL,
                    event_code VARCHAR(100) NOT NULL,
                    created_at VARCHAR(19) NOT NULL,
                    UNIQUE KEY unique_attendance (username, event_code)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ''')
        db.commit()
    else:
        db = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                email TEXT,
                phone TEXT,
                address TEXT,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                subject TEXT NOT NULL,
                description TEXT NOT NULL,
                extra_message TEXT,
                category TEXT NOT NULL,
                status TEXT NOT NULL,
                priority TEXT NOT NULL,
                assigned_to TEXT,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ticket_comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                author TEXT NOT NULL,
                body TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS grades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_username TEXT NOT NULL,
                teacher_username TEXT NOT NULL,
                course TEXT NOT NULL,
                grade TEXT NOT NULL,
                comments TEXT,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                file_path TEXT NOT NULL,
                uploaded_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(ticket_id) REFERENCES tickets(id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS comment_attachments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                comment_id INTEGER NOT NULL,
                filename TEXT NOT NULL,
                file_path TEXT NOT NULL,
                uploaded_by TEXT NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY(comment_id) REFERENCES ticket_comments(id)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pending_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT NOT NULL,
                phone TEXT,
                address TEXT,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender TEXT NOT NULL,
                recipient TEXT NOT NULL,
                subject TEXT NOT NULL,
                body TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                time TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_articles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                body TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS status_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                service TEXT NOT NULL,
                status TEXT NOT NULL,
                message TEXT,
                updated_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ticket_votes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ticket_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(ticket_id, username)
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS inventory_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                asset_tag TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                location TEXT,
                status TEXT NOT NULL,
                assigned_to TEXT,
                notes TEXT,
                updated_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                department TEXT NOT NULL,
                appointment_time TEXT NOT NULL,
                reason TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS calendar_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                event_date TEXT NOT NULL,
                event_time TEXT,
                location TEXT,
                category TEXT NOT NULL,
                description TEXT,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS password_reset_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                email TEXT NOT NULL,
                token TEXT UNIQUE NOT NULL,
                expires_at TEXT NOT NULL,
                used INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                recipient TEXT NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                link TEXT,
                is_read INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS announcements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                priority TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS emergency_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                emergency_type TEXT NOT NULL,
                location TEXT NOT NULL,
                description TEXT,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS attendance_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                event_code TEXT NOT NULL,
                created_at TEXT NOT NULL,
                UNIQUE(username, event_code)
            )
        ''')

        existing_cols = {row[1] for row in cursor.execute('PRAGMA table_info(tickets)').fetchall()}
        for column, ddl in {
            'location': 'ALTER TABLE tickets ADD COLUMN location TEXT',
            'due_at': 'ALTER TABLE tickets ADD COLUMN due_at TEXT',
            'ai_suggestion': 'ALTER TABLE tickets ADD COLUMN ai_suggestion TEXT'
        }.items():
            if column not in existing_cols:
                cursor.execute(ddl)
        db.commit()
        cursor.close()

    if not os.path.exists(UPLOAD_DIR):
        os.makedirs(UPLOAD_DIR)

    for username, data in INITIAL_USERS.items():
        if query_user(username) is None:
            create_user(username, data['password'], data['role'], data['email'], data['phone'], data['address'])
    seed_feature_data()

def query_user(username):
    row = query_db('SELECT * FROM users WHERE username = %s', (username,), one=True)
    return dict(row) if row else None

def get_all_users():
    rows = query_db('SELECT * FROM users ORDER BY username')
    return [dict(row) for row in rows]

def create_user(username, raw_password, role='user', email='', phone='', address=''):
    execute_db(
        'INSERT INTO users (username, password, role, email, phone, address, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
        (username, generate_password_hash(raw_password), role, email, phone, address, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def create_user_with_password_hash(username, password_hash, role='user', email='', phone='', address=''):
    execute_db(
        'INSERT INTO users (username, password, role, email, phone, address, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
        (username, password_hash, role, email, phone, address, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def calculate_due_at(priority):
    hours = {'High': 4, 'Normal': 24, 'Low': 72}.get(priority, 24)
    return (datetime.now() + timedelta(hours=hours)).strftime('%Y-%m-%d %H:%M')


def suggest_ticket_fields(text):
    text = (text or '').lower()
    rules = [
        (['wifi', 'internet', 'network', 'password', 'login', 'computer', 'software', 'printer'], 'IT Support'),
        (['broken', 'room', 'chair', 'desk', 'air condition', 'ac', 'light', 'projector', 'maintenance'], 'Facilities'),
        (['grade', 'course', 'exam', 'teacher', 'class', 'assignment'], 'Academic Affairs'),
        (['library', 'book', 'borrow', 'return'], 'Library'),
        (['security', 'lost', 'stolen', 'unsafe', 'incident'], 'Security'),
        (['payment', 'invoice', 'fee', 'tuition', 'finance'], 'Finance')
    ]
    category = 'General'
    for words, candidate in rules:
        if any(word in text for word in words):
            category = candidate
            break
    priority = 'Normal'
    if any(word in text for word in ['urgent', 'emergency', 'cannot access', 'down', 'unsafe', 'stolen']):
        priority = 'High'
    elif any(word in text for word in ['question', 'information', 'request', 'when possible']):
        priority = 'Low'
    return category, priority


def create_ticket(username, subject, description, category='General', priority='Normal', extra_message='', location=''):
    combined_text = f'{subject} {description} {extra_message}'
    suggested_category, suggested_priority = suggest_ticket_fields(combined_text)
    if category in ['', 'Auto Detect']:
        category = suggested_category
    if priority in ['', 'Auto Detect']:
        priority = suggested_priority
    ai_suggestion = f'Suggested category: {suggested_category}; Suggested priority: {suggested_priority}'
    return execute_db(
        'INSERT INTO tickets (username, subject, description, extra_message, category, status, priority, assigned_to, created_at, location, due_at, ai_suggestion) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)',
        (username, subject, description, extra_message, category, 'Open', priority, None, datetime.now().strftime('%Y-%m-%d %H:%M'), location, calculate_due_at(priority), ai_suggestion),
        commit=True,
        return_lastrowid=True
    )



def update_user_ticket(ticket_id, username, subject, description, category, priority, location):
    execute_db(
        'UPDATE tickets SET subject = %s, description = %s, category = %s, priority = %s, location = %s, due_at = %s WHERE id = %s AND username = %s',
        (subject, description, category, priority, location, calculate_due_at(priority), ticket_id, username),
        commit=True
    )


def delete_user_ticket(ticket_id, username):
    execute_db('DELETE FROM tickets WHERE id = %s AND username = %s', (ticket_id, username), commit=True)


def create_user_appointment(username, department, appointment_time, reason):
    return execute_db(
        'INSERT INTO appointments (username, department, appointment_time, reason, status, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
        (username, department, appointment_time, reason, 'Requested', datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def update_user_appointment(appointment_id, username, department, appointment_time, reason):
    execute_db(
        'UPDATE appointments SET department = %s, appointment_time = %s, reason = %s WHERE id = %s AND username = %s',
        (department, appointment_time, reason, appointment_id, username),
        commit=True
    )


def delete_user_appointment(appointment_id, username):
    execute_db('DELETE FROM appointments WHERE id = %s AND username = %s', (appointment_id, username), commit=True)


def delete_user_message(message_id, username):
    execute_db('DELETE FROM messages WHERE id = %s AND recipient = %s', (message_id, username), commit=True)

def update_ticket_status(ticket_id, status):
    execute_db('UPDATE tickets SET status = %s WHERE id = %s', (status, ticket_id), commit=True)


def assign_ticket(ticket_id, assignee):
    execute_db('UPDATE tickets SET assigned_to = %s WHERE id = %s', (assignee, ticket_id), commit=True)


def add_ticket_comment(ticket_id, author, body):
    execute_db(
        'INSERT INTO ticket_comments (ticket_id, author, body, created_at) VALUES (%s, %s, %s, %s)',
        (ticket_id, author, body, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def get_ticket_comments(ticket_id):
    rows = query_db('SELECT * FROM ticket_comments WHERE ticket_id = %s ORDER BY created_at', (ticket_id,))
    return [dict(row) for row in rows]


def create_grade(student_username, teacher_username, course, grade, comments=''):
    execute_db(
        'INSERT INTO grades (student_username, teacher_username, course, grade, comments, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
        (student_username, teacher_username, course, grade, comments, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def get_student_grades(student_username):
    rows = query_db('SELECT * FROM grades WHERE student_username = %s ORDER BY created_at DESC', (student_username,))
    return [dict(row) for row in rows]


def get_all_grades():
    rows = query_db('SELECT * FROM grades ORDER BY created_at DESC')
    return [dict(row) for row in rows]

def get_teacher_grades(teacher_username):
    rows = query_db('SELECT * FROM grades WHERE teacher_username = %s ORDER BY created_at DESC', (teacher_username,))
    return [dict(row) for row in rows]

def get_student_list():
    rows = query_db('SELECT username FROM users WHERE role = %s ORDER BY username', ('user',))
    return [row['username'] for row in rows]


def update_user(username, email, phone, address, role=None, raw_password=None):
    updates = []
    params = []
    if email is not None:
        updates.append('email = %s')
        params.append(email)
    if phone is not None:
        updates.append('phone = %s')
        params.append(phone)
    if address is not None:
        updates.append('address = %s')
        params.append(address)
    if role is not None:
        updates.append('role = %s')
        params.append(role)
    if raw_password:
        updates.append('password = %s')
        params.append(generate_password_hash(raw_password))
    if not updates:
        return
    params.append(username)
    execute_db(f'UPDATE users SET {", ".join(updates)} WHERE username = %s', params, commit=True)


def delete_user(username):
    execute_db('DELETE FROM users WHERE username = %s', (username,), commit=True)


def load_tickets_from_db():
    rows = query_db('SELECT * FROM tickets ORDER BY created_at DESC')
    tickets = [dict(row) for row in rows]
    for ticket in tickets:
        ticket['comments'] = get_ticket_comments(ticket['id'])
        ticket['attachments'] = get_ticket_attachments(ticket['id'])
        ticket['votes'] = get_ticket_vote_count(ticket['id'])
    return tickets


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def secure_filename_with_uuid(filename):
    filename = secure_filename(filename)
    if not filename or filename == '':
        filename = 'file'
    name, ext = os.path.splitext(filename)
    return f"{uuid.uuid4().hex}_{name}{ext}"


def add_ticket_attachment(ticket_id, filename, file_path, uploaded_by):
    return execute_db(
        'INSERT INTO attachments (ticket_id, filename, file_path, uploaded_by, created_at) VALUES (%s, %s, %s, %s, %s)',
        (ticket_id, filename, file_path, uploaded_by, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def get_ticket_attachments(ticket_id):
    rows = query_db('SELECT * FROM attachments WHERE ticket_id = %s ORDER BY created_at', (ticket_id,))
    return [dict(row) for row in rows]


def get_attachment_by_id(attachment_id):
    row = query_db('SELECT * FROM attachments WHERE id = %s', (attachment_id,), one=True)
    return dict(row) if row else None


def delete_attachment(attachment_id):
    attachment = get_attachment_by_id(attachment_id)
    if attachment and os.path.exists(attachment['file_path']):
        os.remove(attachment['file_path'])
    execute_db('DELETE FROM attachments WHERE id = %s', (attachment_id,), commit=True)


def add_comment_attachment(comment_id, filename, file_path, uploaded_by):
    return execute_db(
        'INSERT INTO comment_attachments (comment_id, filename, file_path, uploaded_by, created_at) VALUES (%s, %s, %s, %s, %s)',
        (comment_id, filename, file_path, uploaded_by, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def get_comment_attachments(comment_id):
    rows = query_db('SELECT * FROM comment_attachments WHERE comment_id = %s ORDER BY created_at', (comment_id,))
    return [dict(row) for row in rows]


def get_comment_attachment_by_id(attachment_id):
    row = query_db('SELECT * FROM comment_attachments WHERE id = %s', (attachment_id,), one=True)
    return dict(row) if row else None


def delete_comment_attachment(attachment_id):
    attachment = get_comment_attachment_by_id(attachment_id)
    if attachment and os.path.exists(attachment['file_path']):
        os.remove(attachment['file_path'])
    execute_db('DELETE FROM comment_attachments WHERE id = %s', (attachment_id,), commit=True)



def password_is_strong(password):
    """Return True when a password meets basic production-friendly rules."""
    if len(password) < 8:
        return False
    checks = [
        any(ch.islower() for ch in password),
        any(ch.isupper() for ch in password),
        any(ch.isdigit() for ch in password),
        any(not ch.isalnum() for ch in password),
    ]
    return all(checks)


def pending_user_by_username(username):
    row = query_db('SELECT * FROM pending_users WHERE username = %s', (username,), one=True)
    return dict(row) if row else None


def get_pending_users():
    rows = query_db('SELECT * FROM pending_users ORDER BY created_at DESC')
    return [dict(row) for row in rows]


def create_pending_user(username, email, phone, address, raw_password, role='user'):
    execute_db(
        'INSERT INTO pending_users (username, email, phone, address, password, role, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
        (username, email, phone, address, generate_password_hash(raw_password), role, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def delete_pending_user(username):
    execute_db('DELETE FROM pending_users WHERE username = %s', (username,), commit=True)


def create_message(sender, recipient, subject, body):
    return execute_db(
        'INSERT INTO messages (sender, recipient, subject, body, is_read, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
        (sender, recipient, subject, body, 0, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def get_inbox_messages(username):
    rows = query_db('SELECT * FROM messages WHERE recipient = %s ORDER BY created_at DESC', (username,))
    messages = [dict(row) for row in rows]
    for message in messages:
        message['read'] = bool(message.get('is_read'))
    return messages


def get_sent_messages(username):
    rows = query_db('SELECT * FROM messages WHERE sender = %s ORDER BY created_at DESC', (username,))
    messages = [dict(row) for row in rows]
    for message in messages:
        message['read'] = bool(message.get('is_read'))
    return messages


def mark_messages_read(username):
    execute_db('UPDATE messages SET is_read = %s WHERE recipient = %s', (1, username), commit=True)


def log_activity(actor, action, details=''):
    execute_db(
        'INSERT INTO activity_log (time, actor, action, details) VALUES (%s, %s, %s, %s)',
        (datetime.now().strftime('%Y-%m-%d %H:%M'), actor or 'system', action, details),
        commit=True
    )


def get_recent_activity(limit=10):
    rows = query_db('SELECT time, actor, action, details FROM activity_log ORDER BY id DESC LIMIT %s', (limit,))
    return [dict(row) for row in rows]


def current_tickets():
    """Always read tickets from the database so changes survive restarts and stay fresh."""
    return load_tickets_from_db()

ROLES = ['user', 'staff', 'it', 'teacher', 'admin', 'owner']


# Ticket categories and templates for user convenience
CATEGORIES = ['Auto Detect', 'IT Support', 'Facilities', 'Administrative', 'Academic Affairs', 'Library', 'Security', 'Finance', 'General']


def password_is_strong(password):
    """Return True when a password meets basic production-friendly rules."""
    if len(password) < 8:
        return False
    checks = [
        any(ch.islower() for ch in password),
        any(ch.isupper() for ch in password),
        any(ch.isdigit() for ch in password),
        any(not ch.isalnum() for ch in password),
    ]
    return all(checks)


def pending_user_by_username(username):
    row = query_db('SELECT * FROM pending_users WHERE username = %s', (username,), one=True)
    return dict(row) if row else None


def get_pending_users():
    rows = query_db('SELECT * FROM pending_users ORDER BY created_at DESC')
    return [dict(row) for row in rows]


def create_pending_user(username, email, phone, address, raw_password, role='user'):
    execute_db(
        'INSERT INTO pending_users (username, email, phone, address, password, role, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s)',
        (username, email, phone, address, generate_password_hash(raw_password), role, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True
    )


def delete_pending_user(username):
    execute_db('DELETE FROM pending_users WHERE username = %s', (username,), commit=True)


def create_message(sender, recipient, subject, body):
    return execute_db(
        'INSERT INTO messages (sender, recipient, subject, body, is_read, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
        (sender, recipient, subject, body, 0, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def get_inbox_messages(username):
    rows = query_db('SELECT * FROM messages WHERE recipient = %s ORDER BY created_at DESC', (username,))
    messages = [dict(row) for row in rows]
    for message in messages:
        message['read'] = bool(message.get('is_read'))
    return messages


def get_sent_messages(username):
    rows = query_db('SELECT * FROM messages WHERE sender = %s ORDER BY created_at DESC', (username,))
    messages = [dict(row) for row in rows]
    for message in messages:
        message['read'] = bool(message.get('is_read'))
    return messages


def mark_messages_read(username):
    execute_db('UPDATE messages SET is_read = %s WHERE recipient = %s', (1, username), commit=True)


def log_activity(actor, action, details=''):
    execute_db(
        'INSERT INTO activity_log (time, actor, action, details) VALUES (%s, %s, %s, %s)',
        (datetime.now().strftime('%Y-%m-%d %H:%M'), actor or 'system', action, details),
        commit=True
    )


def get_recent_activity(limit=10):
    rows = query_db('SELECT time, actor, action, details FROM activity_log ORDER BY id DESC LIMIT %s', (limit,))
    return [dict(row) for row in rows]


def current_tickets():
    """Always read tickets from the database so changes survive restarts and stay fresh."""
    return load_tickets_from_db()

ROLES = ['user', 'staff', 'it', 'teacher', 'admin', 'owner']
TICKET_TEMPLATES = [
    {
        'name': 'Password Reset',
        'subject': 'Password Reset Request',
        'description': 'I need help resetting my account password. Please guide me through the steps or reset it for me.'
    },
    {
        'name': 'WiFi Access Issue',
        'subject': 'WiFi Connection Problem',
        'description': 'I am unable to connect to the campus WiFi. Please investigate and restore my network access.'
    },
    {
        'name': 'Room Maintenance',
        'subject': 'Maintenance Request: Room Issue',
        'description': 'There is a maintenance issue in my assigned room. Please schedule support to resolve it.'
    }
]

FAQ_ARTICLES = [
    {
        'question': 'How do I reset my campus password?',
        'answer': 'Submit a ticket using the Password Reset template, then follow the instructions from support once they respond.'
    },
    {
        'question': 'How can I request a new service desk account?',
        'answer': 'Use the Request Access page to submit your details. An administrator will approve or reject your request.'
    },
    {
        'question': 'How do I check the status of my ticket?',
        'answer': 'Open your dashboard and filter by status to find tickets that are Open or Closed. You can also search by ticket ID.'
    },
    {
        'question': 'Can I add comments to a ticket?',
        'answer': 'Yes. Use the ticket comment form on your dashboard to add updates or additional details to any submitted ticket.'
    }
]



def seed_feature_data():
    if len(query_db('SELECT id FROM knowledge_articles LIMIT 1')) == 0:
        for item in FAQ_ARTICLES:
            execute_db('INSERT INTO knowledge_articles (title, category, body, created_at) VALUES (%s, %s, %s, %s)',
                       (item['question'], 'General', item['answer'], datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
    if len(query_db('SELECT id FROM status_updates LIMIT 1')) == 0:
        for service in ['Campus WiFi', 'Learning Portal', 'Printing', 'Library Systems']:
            execute_db('INSERT INTO status_updates (service, status, message, updated_at) VALUES (%s, %s, %s, %s)',
                       (service, 'Operational', 'No known issues.', datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)


def get_kb_articles(q=''):
    if q:
        rows = query_db('SELECT * FROM knowledge_articles WHERE title LIKE %s OR body LIKE %s ORDER BY id DESC', (f'%{q}%', f'%{q}%'))
    else:
        rows = query_db('SELECT * FROM knowledge_articles ORDER BY id DESC')
    return [dict(r) for r in rows]


def get_status_updates():
    return [dict(r) for r in query_db('SELECT * FROM status_updates ORDER BY service')]


def get_ticket_vote_count(ticket_id):
    row = query_db('SELECT COUNT(*) AS c FROM ticket_votes WHERE ticket_id = %s', (ticket_id,), one=True)
    return int(row['c']) if row else 0


def add_ticket_vote(ticket_id, username):
    try:
        execute_db('INSERT INTO ticket_votes (ticket_id, username, created_at) VALUES (%s, %s, %s)',
                   (ticket_id, username, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
        return True
    except Exception:
        return False


def get_inventory_items():
    return [dict(r) for r in query_db('SELECT * FROM inventory_items ORDER BY updated_at DESC')]


def get_appointments(username=None):
    if username:
        rows = query_db('SELECT * FROM appointments WHERE username = %s ORDER BY appointment_time DESC', (username,))
    else:
        rows = query_db('SELECT * FROM appointments ORDER BY appointment_time DESC')
    return [dict(r) for r in rows]


def get_calendar_events():
    rows = query_db('SELECT * FROM calendar_events ORDER BY event_date ASC, event_time ASC')
    return [dict(r) for r in rows]


def analytics_summary():
    tickets = current_tickets()
    by_status, by_category, by_priority = {}, {}, {}
    for t in tickets:
        by_status[t.get('status','Unknown')] = by_status.get(t.get('status','Unknown'), 0) + 1
        by_category[t.get('category','Unknown')] = by_category.get(t.get('category','Unknown'), 0) + 1
        by_priority[t.get('priority','Unknown')] = by_priority.get(t.get('priority','Unknown'), 0) + 1
    overdue = [t for t in tickets if t.get('status') != 'Closed' and t.get('due_at') and t.get('due_at') < datetime.now().strftime('%Y-%m-%d %H:%M')]
    return {'total': len(tickets), 'by_status': by_status, 'by_category': by_category, 'by_priority': by_priority, 'overdue': overdue}



def get_user_by_email(email):
    row = query_db('SELECT * FROM users WHERE email = %s', (email,), one=True)
    return dict(row) if row else None


def create_notification(recipient, title, body, link=''):
    return execute_db(
        'INSERT INTO notifications (recipient, title, body, link, is_read, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
        (recipient, title, body, link, 0, datetime.now().strftime('%Y-%m-%d %H:%M')),
        commit=True,
        return_lastrowid=True
    )


def get_notifications(username):
    return [dict(r) for r in query_db('SELECT * FROM notifications WHERE recipient = %s ORDER BY id DESC', (username,))]


def mark_notifications_read(username):
    execute_db('UPDATE notifications SET is_read = %s WHERE recipient = %s', (1, username), commit=True)


def create_password_reset_token(user):
    token = secrets.token_urlsafe(32)
    expires = (datetime.now() + timedelta(minutes=30)).strftime('%Y-%m-%d %H:%M')
    execute_db('INSERT INTO password_reset_tokens (username, email, token, expires_at, used, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
               (user['username'], user.get('email',''), token, expires, 0, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
    return token, expires


def get_reset_token(token):
    row = query_db('SELECT * FROM password_reset_tokens WHERE token = %s', (token,), one=True)
    return dict(row) if row else None


def mark_reset_token_used(token):
    execute_db('UPDATE password_reset_tokens SET used = %s WHERE token = %s', (1, token), commit=True)


def send_smtp_email(to_email, subject, body, from_email=None, html_body=None, reply_to=None):
    """Send an email using SMTP settings loaded from .env / environment variables."""
    if not SMTP_HOST:
        return False, 'SMTP_HOST is not configured. Add SMTP settings to .env.'
    if SMTP_REQUIRE_AUTH and (not SMTP_USERNAME or not SMTP_PASSWORD):
        return False, 'SMTP credentials are missing. Add SMTP_USERNAME and SMTP_PASSWORD/App Password to .env.'

    msg = EmailMessage()
    msg['Subject'] = subject
    msg['From'] = from_email or SMTP_FROM
    msg['To'] = to_email
    if reply_to or SMTP_REPLY_TO:
        msg['Reply-To'] = reply_to or SMTP_REPLY_TO
    msg.set_content(body)
    if html_body:
        msg.add_alternative(html_body, subtype='html')

    try:
        context = ssl.create_default_context()
        smtp_class = smtplib.SMTP_SSL if SMTP_USE_SSL else smtplib.SMTP
        if SMTP_USE_SSL:
            server_context = smtp_class(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT, context=context)
        else:
            server_context = smtp_class(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT)
        with server_context as server:
            server.ehlo()
            if SMTP_USE_TLS and not SMTP_USE_SSL:
                server.starttls(context=context)
                server.ehlo()
            if SMTP_REQUIRE_AUTH:
                server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(msg)
        return True, 'Email sent successfully.'
    except smtplib.SMTPAuthenticationError:
        return False, 'SMTP authentication failed. Check the email address and app password.'
    except smtplib.SMTPConnectError:
        return False, 'SMTP connection failed. Check host, port, firewall, and TLS/SSL settings.'
    except Exception as exc:
        return False, f'Email could not be sent: {exc}'


def send_password_reset_email(to_email, reset_url, username):
    subject = 'Smart Campus password reset'
    body = (
        f'Hello {username}\n\n'
        f'Use this link to reset your Smart Campus Service Desk password:\n{reset_url}\n\n'
        'The link expires in 30 minutes. If you did not request this, ignore this email.\n\n'
        'Smart Campus Service Desk'
    )
    html_body = f"""
    <div style=\"font-family:Arial,sans-serif;line-height:1.5;color:#111827\">
        <h2>Reset your Smart Campus password</h2>
        <p>Hello {username},</p>
        <p>Use the button below to reset your Smart Campus Service Desk password.</p>
        <p><a href=\"{reset_url}\" style=\"display:inline-block;background:#2563eb;color:#ffffff;padding:10px 16px;border-radius:8px;text-decoration:none\">Reset password</a></p>
        <p>This link expires in 30 minutes. If you did not request this, ignore this email.</p>
        <p style=\"color:#6b7280;font-size:12px\">{reset_url}</p>
    </div>
    """
    return send_smtp_email(to_email, subject, body, html_body=html_body)

def get_announcements():
    return [dict(r) for r in query_db('SELECT * FROM announcements ORDER BY id DESC')]


def get_emergency_reports():
    return [dict(r) for r in query_db('SELECT * FROM emergency_reports ORDER BY id DESC')]


def campus_ai_reply(message):
    text = (message or '').lower()
    if any(w in text for w in ['wifi','internet','network']):
        return 'For WiFi issues: restart the device, forget/rejoin the campus network, then open an IT Support ticket if it continues.'
    if any(w in text for w in ['password','login','reset']):
        return 'Use Forgot Password on the login page. If SMTP is configured, the system sends a real reset link to your email.'
    if any(w in text for w in ['appointment','book','meeting']):
        return 'Open Appointments from the menu, choose a department, select a time, and submit your request.'
    if any(w in text for w in ['emergency','security','medical','unsafe']):
        return 'Use the Emergency page immediately. For real danger, call campus security or local emergency services first.'
    if any(w in text for w in ['calendar','event','class']):
        return 'Open Calendar to view campus-wide events shared with all users.'
    return 'I can help with tickets, WiFi, password reset, appointments, calendar, emergency reporting, and campus services.'



def admin_change_user_password(target_username, new_password, confirm_password):
    """Allow admin/IT to change another user's password and notify that user."""
    if not target_username or not new_password or not confirm_password:
        return False, 'User and password fields are required.'
    if new_password != confirm_password:
        return False, 'New password and confirmation do not match.'
    if len(new_password) < 6:
        return False, 'Password must be at least 6 characters long.'

    user = query_user(target_username)
    if not user:
        return False, 'Selected user was not found.'

    execute_db(
        'UPDATE users SET password = %s WHERE username = %s',
        (generate_password_hash(new_password), target_username),
        commit=True
    )

    admin_name = session.get('user', 'admin')
    subject = 'Password Changed by Admin'
    body = f'Hello {target_username}, your Smart Campus password was changed by administrator {admin_name}. If you did not request this, contact the admin office immediately.'

    try:
        create_message(admin_name, target_username, subject, body)
    except Exception:
        pass

    try:
        create_notification(target_username, subject, body)
    except Exception:
        pass

    log_activity(admin_name, 'admin_change_user_password', target_username)
    return True, f'Password changed for {target_username}. A message and notification were sent.'


def change_current_user_password(username, current_password, new_password, confirm_password):
    """Validate and change password for the currently logged-in user."""
    if not current_password or not new_password or not confirm_password:
        return False, 'All password fields are required.'
    if new_password != confirm_password:
        return False, 'New password and confirmation do not match.'
    if len(new_password) < 6:
        return False, 'New password must be at least 6 characters long.'

    user = query_user(username)
    if not user:
        return False, 'User account not found.'

    stored_password = user['password']
    valid_current = False
    try:
        valid_current = check_password_hash(stored_password, current_password)
    except Exception:
        valid_current = stored_password == current_password

    if not valid_current:
        return False, 'Current password is incorrect.'

    execute_db(
        'UPDATE users SET password = %s WHERE username = %s',
        (generate_password_hash(new_password), username),
        commit=True
    )
    log_activity(username, 'change_password', 'Password changed from dashboard')
    return True, 'Password changed successfully.'

def login_required(f):
    """Decorator to protect routes - require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function
def admin_required(f):
    """Decorator to protect routes - require admin or owner role"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        if session.get('role') not in ['admin', 'owner', 'it']:
            return redirect(url_for('user_dashboard'))
        return f(*args, **kwargs)
    return decorated_function
def teacher_required(f):
    """Decorator to protect teacher dashboard routes."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        if session.get('role') not in ['teacher', 'admin', 'owner']:
            return redirect(url_for('user_dashboard'))
        return f(*args, **kwargs)
    return decorated_function
def login_ai_assistant(username='', password_provided=False, error_type=None):
    """Rule-based AI-style helper for the login page.
    It gives safe, contextual guidance without exposing sensitive account data.
    """
    username = (username or '').strip().lower()
    tips = []

    if error_type == 'pending':
        mood = 'Account found, but not approved yet'
        tips.append('Your registration is waiting for an administrator to approve it.')
        tips.append('Try again after approval, or contact the campus service desk.')
    elif error_type == 'invalid':
        mood = 'Login attempt needs attention'
        if not username:
            tips.append('Enter your username before signing in.')
        elif '@' in username:
            tips.append('This system usually uses usernames like admin or user, not full email addresses.')
        else:
            tips.append('Check spelling, capitalization, and whether you selected the correct account.')
        if not password_provided:
            tips.append('Enter your password before signing in.')
        else:
            tips.append('Use the demo credentials below if you are testing the project locally.')
    else:
        mood = 'Ready to help you sign in'
        tips.append('Admin users go to the admin dashboard after login.')
        tips.append('Students and staff go to the user dashboard after login.')
        tips.append('If you are only testing, use one of the demo accounts below.')

    return {
        'mood': mood,
        'tips': tips,
        'demo_accounts': [
            {'role': 'Admin', 'username': 'admin', 'password': os.getenv('DEFAULT_ADMIN_PASSWORD', 'ChangeMeAdmin123!')},
            {'role': 'User', 'username': 'user', 'password': os.getenv('DEFAULT_USER_PASSWORD', 'ChangeMeUser123!')},
        ]
    }


def get_database_overview():
    """Return safe database information for the admin MySQL/database page."""
    table_names = [
        'users', 'tickets', 'ticket_comments', 'grades', 'attachments',
        'comment_attachments', 'pending_users', 'messages', 'activity_log',
        'knowledge_articles', 'status_updates', 'ticket_votes', 'inventory_items',
        'appointments', 'calendar_events', 'password_reset_tokens',
        'notifications', 'announcements', 'emergency_reports', 'attendance_records'
    ]
    overview = []
    for table in table_names:
        try:
            row = query_db(f'SELECT COUNT(*) AS count FROM {table}', one=True)
            overview.append({'name': table, 'rows': int(row['count']) if row else 0, 'status': 'OK'})
        except Exception as exc:
            overview.append({'name': table, 'rows': '-', 'status': f'Unavailable: {exc}'})
    return overview


def get_mysql_connection_status():
    """Check MySQL connection only when the app is configured to use MySQL."""
    if not USE_MYSQL:
        return {
            'connected': False,
            'message': 'The application is currently using SQLite. Set DB_TYPE=mysql in .env to use MySQL.'
        }
    try:
        row = query_db('SELECT DATABASE() AS database_name, VERSION() AS version', one=True)
        return {
            'connected': True,
            'message': f"Connected to MySQL database {row.get('database_name', MYSQL_DATABASE)}",
            'version': row.get('version', 'Unknown')
        }
    except Exception as exc:
        return {'connected': False, 'message': str(exc)}

@app.route('/')
def index():
    """Send visitors directly to the login page."""
    return redirect(url_for('login'))


@app.route('/knowledge-base')
def knowledge_base():
    """Public searchable knowledge base page."""
    q = request.args.get('q', '').strip()
    return render_template('knowledge_base.html', articles=get_kb_articles(q), q=q)


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page - handle both form display and credential check"""
    if request.method == 'POST':
        username = request.form.get('username', '')
        password = request.form.get('password', '')
        
        # Check credentials. Supports hashed passwords and upgrades old plain-text seed passwords.
        user = query_user(username)
        password_valid = False
        if user:
            stored_password = user['password']
            try:
                password_valid = check_password_hash(stored_password, password)
            except Exception:
                password_valid = False
            if not password_valid and stored_password == password:
                password_valid = True
                try:
                    execute_db(
                        'UPDATE users SET password = %s WHERE username = %s',
                        (generate_password_hash(password), username),
                        commit=True
                    )
                except Exception:
                    pass

        if user and password_valid:
            session['user'] = username
            session['role'] = user['role']
            
            # Role-based redirect
            if user['role'] in ['admin', 'owner', 'it']:
                return redirect(url_for('admin_dashboard'))
            elif user['role'] == 'teacher':
                return redirect(url_for('teacher_dashboard'))
            else:
                return redirect(url_for('user_dashboard'))

        if pending_user_by_username(username) is not None:
            return render_template('login.html', error='Your account request is pending approval. Please wait for an administrator.', ai_login=login_ai_assistant(username, bool(password), 'pending'))

        return render_template('login.html', error='Invalid credentials', ai_login=login_ai_assistant(username, bool(password), 'invalid'))
    
    return render_template('login.html', ai_login=login_ai_assistant())


@app.route('/api/login-assistant', methods=['POST'])
def api_login_assistant():
    data = request.get_json(silent=True) or {}
    username = data.get('username', '')
    password = data.get('password', '')
    message = (data.get('message') or '').strip().lower()

    # Chat-style assistant responses. This stays safe: it gives demo/help guidance
    # without checking or revealing private password information.
    if message:
        if any(word in message for word in ['admin', 'administrator', 'owner']):
            reply = 'For the demo admin account, use username admin and password ChangeMeAdmin123!. After login, you will be sent to the admin dashboard.'
        elif any(word in message for word in ['user', 'student', 'staff', 'teacher']):
            reply = 'For the demo user account, use username user and password ChangeMeUser123!. Normal users go to the user dashboard after login.'
        elif any(word in message for word in ['password', 'pass', 'forgot', 'reset']):
            reply = 'If this is the demo project, use the demo credentials shown below. For a real account, use the Forgot password link or ask an administrator to reset your password.'
        elif any(word in message for word in ['error', 'invalid', 'wrong', 'not working', 'failed']):
            reply = 'Check that you are typing the username, not the email address. Also make sure the password has the correct uppercase letters, lowercase letters, numbers, and symbols.'
        elif any(word in message for word in ['pending', 'approve', 'approval']):
            reply = 'A pending account must be approved by an admin before it can log in. Try the demo accounts while waiting.'
        elif any(word in message for word in ['hello', 'hi', 'hey']):
            reply = 'Hi! I can help you log in. Ask for admin credentials, user credentials, password help, or login error help.'
        else:
            reply = 'I can help with login credentials, password problems, pending approvals, and invalid-login errors. For testing, try admin / ChangeMeAdmin123! or user / ChangeMeUser123!.'

        return jsonify({
            'reply': reply,
            'mood': 'Chat assistant ready',
            'tips': login_ai_assistant(username, bool(password)).get('tips', []),
            'demo_accounts': login_ai_assistant(username, bool(password)).get('demo_accounts', [])
        })

    return jsonify(login_ai_assistant(username, bool(password)))


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registration page - handle new user requests"""
    message = None

    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        phone = request.form.get('phone', '').strip()
        address = request.form.get('address', '').strip()
        role = request.form.get('role', 'user').strip().lower()
        password = request.form.get('password', '').strip()
        confirm_password = request.form.get('confirm_password', '').strip()

        if role not in ROLES:
            role = 'user'

        if not username or not email or not password or not confirm_password:
            message = 'Please provide username, email, password, and confirmation.'
        elif password != confirm_password:
            message = 'Passwords do not match. Please check and try again.'
        elif not password_is_strong(password):
            message = 'Password must be at least 8 characters and include uppercase, lowercase, number, and symbol.'
        elif query_user(username) is not None:
            message = 'That username is already in use. Please choose another.'
        elif pending_user_by_username(username) is not None:
            message = 'A request for that username is already pending approval.'
        else:
            create_pending_user(username, email, phone, address, password, role)
            message = 'Your account request has been submitted. Please wait for administrator approval.'

    return render_template('register.html', message=message)


@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    message = None
    dev_reset_link = None

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()

        if not email:
            message = 'Please enter your email address.'
        else:
            user = get_user_by_email(email)
            # Keep the same public message to avoid revealing whether the email exists.
            message = 'If that email is registered, password reset instructions will be sent.'
            if user:
                token, expires = create_password_reset_token(user)
                reset_url = f"{APP_BASE_URL.rstrip('/')}{url_for('reset_password', token=token)}"
                sent, detail = send_password_reset_email(email, reset_url, user['username'])
                log_activity('system', 'password_reset_requested', email)
                if not sent and os.getenv('FLASK_DEBUG', '0') == '1':
                    dev_reset_link = reset_url
                    message = f'{message} SMTP is not configured/sending failed, so a development reset link is shown below.'

    return render_template('forgot_password.html', message=message, dev_reset_link=dev_reset_link)


@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    token_row = get_reset_token(token)
    message = None
    valid = bool(token_row and not int(token_row.get('used', 0)) and token_row.get('expires_at', '') >= datetime.now().strftime('%Y-%m-%d %H:%M'))
    if not valid:
        return render_template('reset_password.html', valid=False, message='This reset link is invalid or expired.')
    if request.method == 'POST':
        password = request.form.get('password','')
        confirm = request.form.get('confirm_password','')
        if password != confirm:
            message = 'Passwords do not match.'
        elif not password_is_strong(password):
            message = 'Password must be at least 8 characters and include uppercase, lowercase, number, and symbol.'
        else:
            update_user(token_row['username'], None, None, None, raw_password=password)
            mark_reset_token_used(token)
            create_notification(token_row['username'], 'Password changed', 'Your password was reset successfully.', url_for('login'))
            log_activity('system', 'password_reset_completed', token_row['username'])
    return render_template('reset_password.html', valid=True, message=message)




@app.route('/admin/change-user-password', methods=['POST'])
@admin_required
def admin_change_user_password_route():
    target_username = request.form.get('target_username', '').strip()
    new_password = request.form.get('new_password', '').strip()
    confirm_password = request.form.get('confirm_password', '').strip()
    success, message = admin_change_user_password(target_username, new_password, confirm_password)
    flash(message, 'success' if success else 'danger')
    return redirect(url_for('admin_dashboard'))

@app.route('/change-password', methods=['POST'])
@login_required
def change_password_route():
    username = session.get('user')
    current_password = request.form.get('current_password', '').strip()
    new_password = request.form.get('new_password', '').strip()
    confirm_password = request.form.get('confirm_password', '').strip()
    success, message = change_current_user_password(username, current_password, new_password, confirm_password)
    role = session.get('role')
    if role in ['admin', 'owner', 'it']:
        return redirect(url_for('admin_dashboard', message=message))
    if role == 'teacher':
        return redirect(url_for('teacher_dashboard'))
    return redirect(url_for('user_dashboard'))


@app.route('/admin/send-community-message', methods=['POST'])
@admin_required
def send_community_message():
    audience = request.form.get('audience', 'All Users')
    subject = request.form.get('subject', '').strip()
    body = request.form.get('message', '').strip()

    if not subject or not body:
        flash('Subject and message are required.', 'danger')
        return redirect(url_for('admin_dashboard'))

    if audience == 'Students':
        recipients = query_db("SELECT username FROM users WHERE role = %s", ('user',))
    elif audience == 'Teachers':
        recipients = query_db("SELECT username FROM users WHERE role = %s", ('teacher',))
    elif audience == 'IT Staff':
        recipients = query_db("SELECT username FROM users WHERE role IN (%s, %s)", ('it', 'admin'))
    else:
        recipients = query_db("SELECT username FROM users")

    sent = 0
    for r in recipients:
        try:
            target = r['username']
            create_message(session.get('user', 'admin'), target, subject, body)
            create_notification(target, subject, body)
            sent += 1
        except Exception:
            pass

    flash(f'Community message sent to {sent} users.', 'success')
    return redirect(url_for('admin_dashboard'))



@app.route('/admin/change-user-role', methods=['POST'])
@admin_required
def change_user_role():
    target_username = request.form.get('target_username', '').strip()
    new_role = request.form.get('new_role', '').strip()

    valid_roles = ['user', 'teacher', 'it', 'admin']

    if not target_username or new_role not in valid_roles:
        flash('Invalid user or role.', 'danger')
        return redirect(url_for('admin_dashboard'))

    execute_db(
        'UPDATE users SET role = %s WHERE username = %s',
        (new_role, target_username),
        commit=True
    )

    try:
        create_notification(
            target_username,
            'Role Updated',
            f'Your account role has been changed to {new_role.upper()}.'
        )
    except Exception:
        pass

    log_activity(session.get('user', 'admin'), 'change_user_role', f'{target_username} -> {new_role}')

    flash(f'{target_username} role updated to {new_role.upper()}.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/logout')
def logout():
    """Logout - clear session and redirect to login"""
    session.clear()
    return redirect(url_for('login'))


@app.route('/user/dashboard', methods=['GET', 'POST'])
@login_required
def user_dashboard():
    """User dashboard - protected route"""
    if session.get('role') not in ['user', 'staff', 'teacher']:
        return redirect(url_for('admin_dashboard'))

    message = None
    username = session.get('user')
    categories = CATEGORIES
    ticket_templates = TICKET_TEMPLATES
    prefill_location = request.args.get('location', '').strip()

    tickets_cache = current_tickets()
    user_tickets = [ticket for ticket in tickets_cache if ticket['username'] == username]
    open_ticket_count = sum(1 for ticket in user_tickets if ticket['status'] == 'Open')

    status_filter = request.args.get('status', '').strip()
    category_filter = request.args.get('category', '').strip()
    q = request.args.get('q', '').strip()

    if q:
        user_tickets = [ticket for ticket in user_tickets if q.lower() in ticket.get('subject', '').lower() or q.lower() in ticket.get('category', '').lower() or q.lower() in ticket.get('description', '').lower() or q == str(ticket.get('id'))]
    if status_filter:
        user_tickets = [ticket for ticket in user_tickets if ticket.get('status') == status_filter]
    if category_filter:
        user_tickets = [ticket for ticket in user_tickets if ticket.get('category') == category_filter]

    profile = query_user(username) or {}
    recipient_list = [user['username'] for user in get_all_users() if user['username'] != username]
    inbox_messages = get_inbox_messages(username)
    sent_messages = get_sent_messages(username)
    unread_count = sum(1 for msg in inbox_messages if not msg.get('read', False))

    student_list = get_student_list() if session.get('role') == 'teacher' else []
    user_grades = get_student_grades(username) if session.get('role') == 'user' else []
    teacher_grades = get_all_grades() if session.get('role') == 'teacher' else []

    if request.method == 'POST':
        form_action = request.form.get('form_action', 'create_ticket')

        if form_action == 'change_password':
            current_password = request.form.get('current_password', '').strip()
            new_password = request.form.get('new_password', '').strip()
            confirm_password = request.form.get('confirm_password', '').strip()
            success, message = change_current_user_password(username, current_password, new_password, confirm_password)

        elif form_action == 'send_message':
            recipient = request.form.get('recipient', '').strip()
            msg_subject = request.form.get('message_subject', '').strip()
            msg_body = request.form.get('message_body', '').strip()

            if recipient not in recipient_list:
                message = 'Please select a valid recipient.'
            elif not msg_subject or not msg_body:
                message = 'Please provide both a subject and message body.'
            else:
                create_message(username, recipient, msg_subject, msg_body)
                create_notification(recipient, 'Message Received', f'New message from {username}: {msg_subject}')
                message = f'Message sent to {recipient}.'
                log_activity(username, 'send_message', f'{recipient}: {msg_subject}')
                inbox_messages = get_inbox_messages(username)
                sent_messages = get_sent_messages(username)
                unread_count = sum(1 for msg in inbox_messages if not msg.get('read', False))

        elif form_action == 'mark_read':
            mark_messages_read(username)
            inbox_messages = get_inbox_messages(username)
            message = 'All notifications marked as read.'
            unread_count = 0

        elif form_action == 'update_profile':
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            address = request.form.get('address', '').strip()
            update_user(username, email, phone, address)
            profile = query_user(username) or {}
            message = 'Profile updated successfully.'
            log_activity(username, 'update_profile', username)

        elif form_action == 'update_ticket':
            ticket_id = int(request.form.get('ticket_id', '0'))
            subject = request.form.get('subject', '').strip()
            description = request.form.get('description', '').strip()
            category = request.form.get('category', 'General').strip() or 'General'
            priority = request.form.get('priority', 'Normal').strip() or 'Normal'
            location = request.form.get('location', '').strip()
            if category not in categories:
                category = 'General'
            if priority not in ['Low', 'Normal', 'High', 'Auto Detect']:
                priority = 'Normal'
            if not subject or not description:
                message = 'Ticket subject and description are required.'
            else:
                update_user_ticket(ticket_id, username, subject, description, category, priority, location)
                message = f'Ticket #{ticket_id} updated.'
                log_activity(username, 'update_ticket', f'#{ticket_id}')

        elif form_action == 'delete_ticket':
            ticket_id = int(request.form.get('ticket_id', '0'))
            delete_user_ticket(ticket_id, username)
            message = f'Ticket #{ticket_id} deleted.'
            log_activity(username, 'delete_ticket', f'#{ticket_id}')

        elif form_action == 'create_appointment':
            department = request.form.get('department', '').strip()
            appointment_time = request.form.get('appointment_time', '').strip()
            reason = request.form.get('reason', '').strip()
            if not department or not appointment_time or not reason:
                message = 'Please complete all appointment fields.'
            else:
                create_user_appointment(username, department, appointment_time, reason)
                message = 'Appointment requested successfully.'
                log_activity(username, 'create_appointment', department)

        elif form_action == 'update_appointment':
            appointment_id = int(request.form.get('appointment_id', '0'))
            department = request.form.get('department', '').strip()
            appointment_time = request.form.get('appointment_time', '').strip()
            reason = request.form.get('reason', '').strip()
            if not department or not appointment_time or not reason:
                message = 'Please complete all appointment fields.'
            else:
                update_user_appointment(appointment_id, username, department, appointment_time, reason)
                message = f'Appointment #{appointment_id} updated.'
                log_activity(username, 'update_appointment', f'#{appointment_id}')

        elif form_action == 'delete_appointment':
            appointment_id = int(request.form.get('appointment_id', '0'))
            delete_user_appointment(appointment_id, username)
            message = f'Appointment #{appointment_id} deleted.'
            log_activity(username, 'delete_appointment', f'#{appointment_id}')

        elif form_action == 'delete_notification':
            message_id = int(request.form.get('message_id', '0'))
            delete_user_message(message_id, username)
            message = 'Notification deleted.'

        elif form_action == 'add_comment':
            ticket_id = int(request.form.get('ticket_id', '0'))
            comment_body = request.form.get('comment_body', '').strip()
            ticket = next((item for item in user_tickets if item['id'] == ticket_id), None)

            if ticket is None:
                message = 'Invalid ticket selected for comment.'
            elif not comment_body:
                message = 'Please enter a comment before submitting.'
            else:
                add_ticket_comment(ticket_id, username, comment_body)
                ticket.setdefault('comments', []).append({
                    'author': username,
                    'body': comment_body,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M')
                })
                message = f'Comment added to ticket #{ticket_id}.'
                log_activity(username, 'comment_ticket', f'#{ticket_id}')

        elif form_action == 'reopen_ticket':
            ticket_id = int(request.form.get('ticket_id', '0'))
            ticket = next((item for item in user_tickets if item['id'] == ticket_id), None)

            if ticket is None:
                message = 'Ticket not found.'
            elif ticket.get('status') != 'Closed':
                message = 'Only closed tickets can be reopened.'
            else:
                update_ticket_status(ticket_id, 'Open')
                ticket['status'] = 'Open'
                message = f'Ticket #{ticket_id} has been reopened.'
                open_ticket_count = sum(1 for ticket in user_tickets if ticket['status'] == 'Open')
                log_activity(username, 'reopen_ticket', f'#{ticket_id}')

        elif form_action == 'assign_grade' and session.get('role') == 'teacher':
            student_username = request.form.get('student_username', '').strip()
            course = request.form.get('course', '').strip()
            grade_value = request.form.get('grade', '').strip()
            comments = request.form.get('comments', '').strip()

            if student_username not in student_list:
                message = 'Please select a valid student.'
            elif not course or not grade_value:
                message = 'Please provide both course name and grade.'
            else:
                create_grade(student_username, username, course, grade_value, comments)
                teacher_grades = get_all_grades()
                message = f'Grade {grade_value} for {student_username} has been recorded.'
                log_activity(username, 'assign_grade', f'{student_username}: {course} = {grade_value}')

        else:
            subject = request.form.get('subject', '').strip()
            description = request.form.get('description', '').strip()
            extra_message = request.form.get('extra_message', '').strip()
            category = request.form.get('category', 'General').strip() or 'General'
            priority = request.form.get('priority', 'Normal').strip() or 'Normal'
            location = request.form.get('location', '').strip()

            if category not in categories:
                category = 'General'
            if priority not in ['Low', 'Normal', 'High', 'Auto Detect']:
                priority = 'Normal'

            if not subject or not description:
                message = 'Please provide both a subject and a description for the ticket.'
            else:
                ticket_id = create_ticket(username, subject, description, category, priority, extra_message, location)
                new_ticket = {
                    'id': ticket_id,
                    'username': username,
                    'subject': subject,
                    'description': description,
                    'extra_message': extra_message,
                    'category': category,
                    'status': 'Open',
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M'),
                    'assigned_to': None,
                    'priority': priority,
                    'location': location,
                    'due_at': calculate_due_at(priority),
                    'comments': [],
                    'attachments': []
                }
                
                # Handle file upload
                if 'ticket_file' in request.files:
                    file = request.files['ticket_file']
                    if file and file.filename != '' and allowed_file(file.filename):
                        # Check file size
                        file.seek(0, os.SEEK_END)
                        file_size = file.tell()
                        file.seek(0)
                        
                        if file_size <= MAX_FILE_SIZE:
                            secure_name = secure_filename_with_uuid(file.filename)
                            file_path = os.path.join(UPLOAD_DIR, secure_name)
                            file.save(file_path)
                            attachment_id = add_ticket_attachment(ticket_id, file.filename, file_path, username)
                            new_ticket['attachments'].append({
                                'id': attachment_id,
                                'filename': file.filename,
                                'file_path': file_path,
                                'uploaded_by': username,
                                'created_at': datetime.now().strftime('%Y-%m-%d %H:%M')
                            })
                        else:
                            message = 'File is too large. Ticket created but file not uploaded.'
                    elif file and file.filename != '' and not allowed_file(file.filename):
                        message = 'Invalid file type. Ticket created but file not uploaded.'
                
                user_tickets.append(new_ticket)
                open_ticket_count += 1
                if not message:
                    message = f'Ticket #{ticket_id} has been created successfully.'
                else:
                    message = f'Ticket #{ticket_id} has been created successfully. Note: {message}'
                log_activity(username, 'create_ticket', f'#{ticket_id}')

    tickets_cache = current_tickets()
    user_tickets = [ticket for ticket in tickets_cache if ticket['username'] == username]
    open_ticket_count = sum(1 for ticket in user_tickets if ticket['status'] == 'Open')
    profile = query_user(username) or {}
    inbox_messages = get_inbox_messages(username)
    sent_messages = get_sent_messages(username)
    unread_count = sum(1 for msg in inbox_messages if not msg.get('read', False))
    user_appointments = get_appointments(username)

    available_message_users = query_db("SELECT username, role FROM users WHERE username != %s ORDER BY role, username", (username,))
    return render_template('user/dashboard.html', available_message_users=available_message_users,
        username=username,
        tickets=user_tickets,
        open_ticket_count=open_ticket_count,
        categories=categories,
        ticket_templates=ticket_templates,
        message=message,
        q=q,
        user_profile=profile,
        recipient_list=recipient_list,
        inbox_messages=inbox_messages,
        sent_messages=sent_messages,
        unread_count=unread_count,
        student_list=student_list,
        user_grades=user_grades,
        teacher_grades=teacher_grades,
        prefill_location=prefill_location,
        user_appointments=user_appointments,
        calendar_events=get_calendar_events(),
        announcements=get_announcements()[:8],
        system_status=get_status_updates()[:6]
    )






@app.route('/teacher/dashboard', methods=['GET', 'POST'])
@teacher_required
def teacher_dashboard():
    """Teacher dashboard uses the same full dashboard experience as the user dashboard."""
    return user_dashboard()


@app.route('/admin/users', methods=['GET', 'POST'])
@admin_required
def admin_users():
    """Admin user management page for creating, editing, and removing users."""
    message = None
    edit_user = None

    if request.method == 'POST':
        action = request.form.get('action')

        if action == 'create':
            new_username = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            address = request.form.get('address', '').strip()
            role = request.form.get('role', 'user').strip().lower()

            if role not in ROLES:
                role = 'user'

            if not new_username or not password or not email:
                message = 'Username, email, and password are required.'
            elif not password_is_strong(password):
                message = 'Password must be at least 8 characters and include uppercase, lowercase, number, and symbol.'
            elif query_user(new_username) is not None:
                message = 'This username already exists.'
            else:
                create_user(new_username, password, role, email, phone, address)
                message = f"User '{new_username}' has been created."
                log_activity(session.get('user'), 'create_user', new_username)

        elif action == 'delete':
            target_username = request.form.get('username', '').strip()

            if target_username == 'admin':
                message = 'The admin account cannot be deleted.'
            elif target_username == session.get('user'):
                message = 'You cannot delete the currently logged-in account.'
            elif query_user(target_username) is not None:
                delete_user(target_username)
                message = f"User '{target_username}' has been deleted."
                log_activity(session.get('user'), 'delete_user', target_username)
            else:
                message = 'User not found.'

        elif action == 'edit_user':
            edit_username = request.form.get('username', '').strip()
            user = query_user(edit_username)
            if user and edit_username != 'admin':
                edit_user = {'username': edit_username, **user}
            else:
                message = 'Unable to edit this user.'

        elif action == 'update_user':
            edit_username = request.form.get('username', '').strip()
            if query_user(edit_username) is not None and edit_username != 'admin':
                email = request.form.get('email', '').strip()
                phone = request.form.get('phone', '').strip()
                address = request.form.get('address', '').strip()
                role = request.form.get('role', 'user').strip().lower()
                password = request.form.get('password', '').strip()

                if role not in ROLES:
                    role = 'user'

                if not email:
                    message = 'Email is required for user updates.'
                elif password and not password_is_strong(password):
                    message = 'New password must be at least 8 characters and include uppercase, lowercase, number, and symbol.'
                else:
                    update_user(edit_username, email, phone, address, role, password)
                    message = f"User '{edit_username}' has been updated."
                    log_activity(session.get('user'), 'update_user', edit_username)
            else:
                message = 'Unable to update this user.'

        elif action == 'approve_request':
            request_username = request.form.get('username', '').strip()
            request_item = pending_user_by_username(request_username)
            if request_item:
                if query_user(request_username):
                    message = f"User '{request_username}' already exists."
                else:
                    create_user_with_password_hash(request_username, request_item['password'], request_item['role'], request_item.get('email', ''), request_item.get('phone', ''), request_item.get('address', ''))
                    delete_pending_user(request_username)
                    message = f"User '{request_username}' has been approved."
                    log_activity(session.get('user'), 'approve_request', request_username)
            else:
                message = 'Pending request not found.'

        elif action == 'reject_request':
            request_username = request.form.get('username', '').strip()
            request_item = pending_user_by_username(request_username)
            if request_item:
                delete_pending_user(request_username)
                message = f"Request for '{request_username}' has been rejected."
                log_activity(session.get('user'), 'reject_request', request_username)
            else:
                message = 'Pending request not found.'

    users = get_all_users()
    pending_requests = [
        {
            'username': item['username'],
            'email': item.get('email', ''),
            'phone': item.get('phone', ''),
            'address': item.get('address', ''),
            'role': item['role']
        }
        for item in get_pending_users()
    ]
    return render_template('admin/users.html', username=session.get('user'), users=users, requests=pending_requests, message=message, edit_user=edit_user)

def initialize_database():
    with app.app_context():
        init_db()
        return load_tickets_from_db()

initialize_database()

@app.route('/admin/tickets', methods=['GET', 'POST'])
@admin_required
def admin_tickets():
    """Admin ticket management page."""
    message = None

    if request.method == 'POST':
        action = request.form.get('action')
        ticket_id = int(request.form.get('ticket_id', '0'))
        tickets_cache = current_tickets()
        ticket = next((item for item in tickets_cache if item['id'] == ticket_id), None)

        if ticket is None:
            message = 'Ticket not found.'
        elif action == 'resolve':
            update_ticket_status(ticket_id, 'Closed')
            ticket['status'] = 'Closed'
            message = f"Ticket #{ticket_id} has been marked as resolved."
            log_activity(session.get('user'), 'resolve_ticket', f"#{ticket_id}")
        elif action == 'assign':
            assignee = request.form.get('assignee', '').strip()
            assignee_user = query_user(assignee)
            if assignee and assignee_user and assignee_user['role'] in ['admin', 'owner', 'it', 'staff', 'teacher']:
                assign_ticket(ticket_id, assignee)
                ticket['assigned_to'] = assignee
                message = f"Ticket #{ticket_id} assigned to {assignee}."
                log_activity(session.get('user'), 'assign_ticket', f"#{ticket_id} -> {assignee}")
            else:
                message = 'Invalid assignee.'
        elif action == 'comment_ticket':
            comment_body = request.form.get('comment_body', '').strip()
            if not comment_body:
                message = 'Please add a comment before submitting.'
            else:
                add_ticket_comment(ticket_id, session.get('user'), comment_body)
                ticket.setdefault('comments', []).append({
                    'author': session.get('user'),
                    'body': comment_body,
                    'created_at': datetime.now().strftime('%Y-%m-%d %H:%M')
                })
                message = f'Comment added to ticket #{ticket_id}.'
                log_activity(session.get('user'), 'comment_ticket', f"#{ticket_id}")

    users = get_all_users()
    return render_template('admin/tickets.html', username=session.get('user'), tickets=current_tickets(), message=message, users=users)


@app.route('/admin/dashboard', methods=['GET', 'POST'])
@admin_required
def admin_dashboard():
    """Admin dashboard with overview cards, ticket queue, pending requests and activity feed."""
    message = None

    if request.method == 'POST':
        action = request.form.get('action')
        request_username = request.form.get('username', '').strip()

        if action == 'create_dashboard_user':
            new_username = request.form.get('new_username', '').strip()
            password = request.form.get('password', '').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            address = request.form.get('address', '').strip()
            role = request.form.get('role', 'user').strip().lower()

            dashboard_roles = ['user', 'teacher', 'it', 'admin']
            if role not in dashboard_roles:
                role = 'user'

            if not new_username or not password or not email:
                message = 'Username, email, and password are required.'
            elif not password_is_strong(password):
                message = 'Password must be at least 8 characters and include uppercase, lowercase, number, and symbol.'
            elif query_user(new_username) is not None:
                message = f"User '{new_username}' already exists."
            else:
                create_user(new_username, password, role, email, phone, address)
                message = f"{role.title()} account '{new_username}' has been created."
                log_activity(session.get('user'), 'create_dashboard_user', f'{new_username} ({role})')

        elif action == 'approve_request':
            request_item = pending_user_by_username(request_username)
            if request_item:
                if query_user(request_username):
                    message = f"User '{request_username}' already exists."
                else:
                    create_user_with_password_hash(
                        request_username,
                        request_item['password'],
                        request_item['role'],
                        request_item.get('email', ''),
                        request_item.get('phone', ''),
                        request_item.get('address', '')
                    )
                    delete_pending_user(request_username)
                    message = f"User '{request_username}' has been approved."
                    log_activity(session.get('user'), 'approve_request_dashboard', request_username)
            else:
                message = 'Pending request not found.'

        elif action == 'reject_request':
            request_item = pending_user_by_username(request_username)
            if request_item:
                delete_pending_user(request_username)
                message = f"Request for '{request_username}' has been rejected."
                log_activity(session.get('user'), 'reject_request_dashboard', request_username)
            else:
                message = 'Pending request not found.'

    pending_count = len(get_pending_users())
    tickets_cache = current_tickets()
    open_tickets = [t for t in tickets_cache if t['status'] == 'Open']
    open_count = len(open_tickets)
    # resolved today (created_at used as simple marker here)
    today = datetime.now().strftime('%Y-%m-%d')
    resolved_today = sum(1 for t in tickets_cache if t['status'] == 'Closed' and t.get('created_at','').startswith(today))
    recent_activity = get_recent_activity(10)
    # Simple ticket queue (limit 50) with optional filtering
    ticket_queue = sorted(tickets_cache, key=lambda x: x['created_at'], reverse=True)
    q = request.args.get('q', '').strip()
    status_filter = request.args.get('status', '').strip()
    if q:
        ticket_queue = [t for t in ticket_queue if q.lower() in t.get('subject','').lower() or q.lower() in t.get('username','').lower() or q == str(t.get('id'))]
    if status_filter:
        ticket_queue = [t for t in ticket_queue if t.get('status') == status_filter]
    ticket_queue = ticket_queue[:50]
    admins = [user['username'] for user in get_all_users() if user['role'] in ['admin', 'owner', 'it']]

    pending_requests = [{'username': item['username'], 'email': item.get('email',''), 'role': item['role']} for item in get_pending_users()]

    admin_user = session.get('user')
    try:
        admin_notifications = get_notifications(admin_user)[:20]
    except Exception:
        admin_notifications = []
    try:
        attendance_records = [dict(r) for r in query_db('SELECT * FROM attendance_records ORDER BY id DESC LIMIT 30')]
    except Exception:
        attendance_records = []

    return render_template(
        'admin/dashboard.html',
        username=admin_user,
        pending_count=pending_count,
        open_count=open_count,
        resolved_today=resolved_today,
        recent_activity=recent_activity,
        ticket_queue=ticket_queue,
        admins=admins,
        pending_requests=pending_requests,
        analytics=analytics_summary(),
        calendar_events=get_calendar_events()[:20],
        announcements=get_announcements()[:20],
        inventory_items=get_inventory_items()[:30],
        appointments=get_appointments()[:30],
        emergency_reports=get_emergency_reports()[:30],
        admin_notifications=admin_notifications,
        attendance_records=attendance_records,
        users=get_all_users(),
        message=message
    )


@app.route('/admin/reports/export')
@admin_required
def admin_export_reports():
    # Simple CSV export of tickets
    from io import StringIO
    import csv

    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(['id','username','subject','category','status','assigned_to','priority','created_at'])
    for t in current_tickets():
        cw.writerow([t.get('id'), t.get('username'), t.get('subject'), t.get('category'), t.get('status'), t.get('assigned_to'), t.get('priority'), t.get('created_at')])

    return si.getvalue(), 200, {'Content-Type':'text/csv', 'Content-Disposition':'attachment; filename="tickets_export.csv"'}


@app.route('/api/assistant/suggest', methods=['POST'])
@login_required
def assistant_suggest():
    data = request.get_json(silent=True) or {}
    category, priority = suggest_ticket_fields(data.get('text', ''))
    return jsonify({'category': category, 'priority': priority})


@app.route('/status')
def public_status():
    return render_template('status.html', updates=get_status_updates())


@app.route('/report/<path:location>')
def report_location(location):
    return redirect(url_for('user_dashboard', location=location))


@app.route('/ticket/<int:ticket_id>/vote', methods=['POST'])
@login_required
def vote_ticket(ticket_id):
    username = session.get('user')
    added = add_ticket_vote(ticket_id, username)
    log_activity(username, 'vote_ticket', f'#{ticket_id}' if added else f'#{ticket_id} duplicate')
    return redirect(request.referrer or url_for('user_dashboard'))


@app.route('/calendar')
@login_required
def calendar():
    return render_template('calendar.html', events=get_calendar_events())


@app.route('/admin/calendar', methods=['GET', 'POST'])
@admin_required
def admin_calendar():
    message = None
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        event_date = request.form.get('event_date','').strip()
        event_time = request.form.get('event_time','').strip()
        location = request.form.get('location','').strip()
        category = request.form.get('category','Campus').strip()
        description = request.form.get('description','').strip()
        if title and event_date:
            execute_db('INSERT INTO calendar_events (title, event_date, event_time, location, category, description, created_by, created_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)',
                       (title, event_date, event_time, location, category, description, session.get('user'), datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            message = 'Calendar event added for all users.'
            log_activity(session.get('user'), 'create_calendar_event', title)
        else:
            message = 'Title and date are required.'
    return render_template('admin/calendar.html', username=session.get('user'), events=get_calendar_events(), message=message)


@app.route('/admin/analytics')
@admin_required
def admin_analytics():
    return render_template('admin/analytics.html', username=session.get('user'), analytics=analytics_summary())


@app.route('/admin/knowledge', methods=['GET', 'POST'])
@admin_required
def admin_knowledge():
    message = None
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        category = request.form.get('category','General').strip()
        body = request.form.get('body','').strip()
        if title and body:
            execute_db('INSERT INTO knowledge_articles (title, category, body, created_at) VALUES (%s, %s, %s, %s)',
                       (title, category, body, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            message = 'Knowledge-base article added.'
            log_activity(session.get('user'), 'create_kb_article', title)
        else:
            message = 'Title and body are required.'
    return render_template('admin/knowledge.html', username=session.get('user'), articles=get_kb_articles(), message=message)


@app.route('/admin/status', methods=['GET', 'POST'])
@admin_required
def admin_status():
    message = None
    if request.method == 'POST':
        service = request.form.get('service','').strip()
        status_value = request.form.get('status','Operational').strip()
        update_message = request.form.get('message','').strip()
        if service:
            execute_db('INSERT INTO status_updates (service, status, message, updated_at) VALUES (%s, %s, %s, %s)',
                       (service, status_value, update_message, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            message = 'Status update published.'
            log_activity(session.get('user'), 'status_update', service)
    return render_template('admin/status.html', username=session.get('user'), updates=get_status_updates(), message=message)


@app.route('/admin/inventory', methods=['GET', 'POST'])
@admin_required
def admin_inventory():
    message = None
    if request.method == 'POST':
        asset_tag = request.form.get('asset_tag','').strip()
        name = request.form.get('name','').strip()
        category = request.form.get('category','IT').strip()
        location = request.form.get('location','').strip()
        status_value = request.form.get('status','Available').strip()
        assigned_to = request.form.get('assigned_to','').strip()
        notes = request.form.get('notes','').strip()
        if asset_tag and name:
            try:
                execute_db('INSERT INTO inventory_items (asset_tag, name, category, location, status, assigned_to, notes, updated_at) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)',
                           (asset_tag, name, category, location, status_value, assigned_to, notes, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
                message = 'Inventory item added.'
                log_activity(session.get('user'), 'add_inventory', asset_tag)
            except Exception:
                message = 'Asset tag already exists.'
        else:
            message = 'Asset tag and name are required.'
    return render_template('admin/inventory.html', username=session.get('user'), items=get_inventory_items(), message=message)


@app.route('/appointments', methods=['GET', 'POST'])
@login_required
def appointments():
    message = None
    username = session.get('user')
    if request.method == 'POST':
        department = request.form.get('department','IT Support').strip()
        appointment_time = request.form.get('appointment_time','').strip()
        reason = request.form.get('reason','').strip()
        if department and appointment_time and reason:
            execute_db('INSERT INTO appointments (username, department, appointment_time, reason, status, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
                       (username, department, appointment_time, reason, 'Requested', datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            message = 'Appointment request submitted.'
            log_activity(username, 'request_appointment', department)
        else:
            message = 'Please complete all appointment fields.'
    return render_template('appointments.html', message=message, appointments=get_appointments(username), categories=CATEGORIES)


@app.route('/admin/appointments')
@admin_required
def admin_appointments():
    return render_template('admin/appointments.html', username=session.get('user'), appointments=get_appointments())


@app.route('/admin/escalate', methods=['POST'])
@admin_required
def admin_escalate():
    overdue = analytics_summary()['overdue']
    for ticket in overdue:
        if not ticket.get('assigned_to'):
            assign_ticket(ticket['id'], session.get('user'))
        create_message('system', ticket['username'], f'Ticket #{ticket["id"]} escalated', 'Your ticket passed its SLA target and has been escalated for review.')
        log_activity(session.get('user'), 'escalate_ticket', f'#{ticket["id"]}')
    return redirect(url_for('admin_analytics'))


@app.route('/admin/mysql')
@admin_required
def admin_mysql_page():
    """Admin page for checking the configured database/MySQL connection."""
    return render_template(
        'admin/mysql.html',
        db_type=DB_TYPE,
        use_mysql=USE_MYSQL,
        mysql_host=MYSQL_HOST,
        mysql_port=MYSQL_PORT,
        mysql_user=MYSQL_USER,
        mysql_database=MYSQL_DATABASE,
        sqlite_database=DATABASE,
        connection_status=get_mysql_connection_status(),
        database_overview=get_database_overview()
    )


@app.route('/admin/smtp', methods=['GET', 'POST'])
@admin_required
def admin_smtp_page():
    """Admin page for checking SMTP configuration and sending a test email."""
    message = None
    message_type = 'info'
    if request.method == 'POST':
        test_to = request.form.get('test_to', '').strip()
        if not test_to:
            message = 'Enter a recipient email address for the test.'
            message_type = 'warning'
        else:
            subject = 'Smart Campus SMTP test'
            body = (
                'This is a test email from Smart Campus Service Desk.\n\n'
                'If you received this message, SMTP is configured correctly.\n\n'
                f'Sent at: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}'
            )
            ok, result = send_smtp_email(test_to, subject, body)
            message = result
            message_type = 'success' if ok else 'danger'

    config = {
        'host': SMTP_HOST or '(not set)',
        'port': SMTP_PORT,
        'username': SMTP_USERNAME or '(not set)',
        'from': SMTP_FROM or '(not set)',
        'use_tls': SMTP_USE_TLS,
        'use_ssl': SMTP_USE_SSL,
        'app_base_url': APP_BASE_URL,
        'reply_to': SMTP_REPLY_TO or '(not set)',
        'timeout': SMTP_TIMEOUT,
        'require_auth': SMTP_REQUIRE_AUTH,
        'configured': bool(SMTP_HOST and (not SMTP_REQUIRE_AUTH or (SMTP_USERNAME and SMTP_PASSWORD))),
        'password_set': bool(SMTP_PASSWORD),
    }
    return render_template('admin/smtp.html', config=config, message=message, message_type=message_type)


@app.route('/admin/settings')
@admin_required
def admin_settings():
    return render_template('admin/settings.html', username=session.get('user'))



@app.route('/notifications')
@login_required
def notifications():
    username = session.get('user')
    items = get_notifications(username)
    mark_notifications_read(username)
    return render_template('notifications.html', notifications=items)


@app.route('/announcements')
def announcements():
    return render_template('announcements.html', announcements=get_announcements())


@app.route('/admin/announcements', methods=['GET', 'POST'])
@admin_required
def admin_announcements():
    message = None
    if request.method == 'POST':
        title = request.form.get('title','').strip()
        body = request.form.get('body','').strip()
        priority = request.form.get('priority','Normal').strip()
        if title and body:
            execute_db('INSERT INTO announcements (title, body, priority, created_by, created_at) VALUES (%s, %s, %s, %s, %s)',
                       (title, body, priority, session.get('user'), datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            for u in get_all_users():
                create_notification(u['username'], f'Announcement: {title}', body[:180], url_for('announcements'))
            message = 'Announcement published and notifications created.'
            log_activity(session.get('user'), 'create_announcement', title)
        else:
            message = 'Title and body are required.'
    return render_template('admin/announcements.html', announcements=get_announcements(), message=message)


@app.route('/emergency', methods=['GET', 'POST'])
@login_required
def emergency():
    message = None
    if request.method == 'POST':
        emergency_type = request.form.get('emergency_type','Security').strip()
        location = request.form.get('location','').strip()
        description = request.form.get('description','').strip()
        if location:
            execute_db('INSERT INTO emergency_reports (username, emergency_type, location, description, status, created_at) VALUES (%s, %s, %s, %s, %s, %s)',
                       (session.get('user'), emergency_type, location, description, 'Open', datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
            for u in get_all_users():
                if u['role'] in ['admin','owner','it']:
                    create_notification(u['username'], 'Emergency report submitted', f'{emergency_type} at {location}', url_for('admin_emergency'))
            message = 'Emergency report submitted. Contact real emergency services immediately if there is danger.'
            log_activity(session.get('user'), 'emergency_report', f'{emergency_type} at {location}')
        else:
            message = 'Location is required.'
    return render_template('emergency.html', message=message)


@app.route('/admin/emergency')
@admin_required
def admin_emergency():
    return render_template('admin/emergency.html', reports=get_emergency_reports())


@app.route('/attendance', methods=['GET', 'POST'])
@login_required
def attendance():
    message = None
    if request.method == 'POST':
        event_code = request.form.get('event_code','').strip().upper()
        if event_code:
            try:
                execute_db('INSERT INTO attendance_records (username, event_code, created_at) VALUES (%s, %s, %s)',
                           (session.get('user'), event_code, datetime.now().strftime('%Y-%m-%d %H:%M')), commit=True)
                message = 'Attendance recorded.'
                log_activity(session.get('user'), 'attendance_scan', event_code)
            except Exception:
                message = 'Attendance was already recorded for this code.'
        else:
            message = 'Enter an event/class code.'
    records = [dict(r) for r in query_db('SELECT * FROM attendance_records WHERE username = %s ORDER BY id DESC', (session.get('user'),))]
    return render_template('attendance.html', message=message, records=records)


@app.route('/admin/attendance')
@admin_required
def admin_attendance():
    records = [dict(r) for r in query_db('SELECT * FROM attendance_records ORDER BY id DESC')]
    return render_template('admin/attendance.html', records=records)


@app.route('/search')
@login_required
def advanced_search():
    q = request.args.get('q','').strip()
    results = {'tickets': [], 'knowledge': [], 'calendar': [], 'inventory': []}
    if q:
        like = f'%{q}%'
        results['tickets'] = [dict(r) for r in query_db('SELECT * FROM tickets WHERE subject LIKE %s OR description LIKE %s OR category LIKE %s ORDER BY id DESC LIMIT 30', (like, like, like))]
        results['knowledge'] = get_kb_articles(q)
        results['calendar'] = [dict(r) for r in query_db('SELECT * FROM calendar_events WHERE title LIKE %s OR description LIKE %s OR location LIKE %s ORDER BY event_date DESC LIMIT 30', (like, like, like))]
        if session.get('role') in ['admin','owner','it']:
            results['inventory'] = [dict(r) for r in query_db('SELECT * FROM inventory_items WHERE asset_tag LIKE %s OR name LIKE %s OR location LIKE %s ORDER BY updated_at DESC LIMIT 30', (like, like, like))]
    return render_template('search.html', q=q, results=results)


@app.route('/student-portal')
@login_required
def student_portal():
    username = session.get('user')
    my_tickets = [t for t in current_tickets() if t.get('username') == username]
    return render_template('student_portal.html', tickets=my_tickets[:8], grades=get_student_grades(username), appointments=get_appointments(username), announcements=get_announcements()[:5])


@app.route('/campus-ai', methods=['GET', 'POST'])
@login_required
def campus_ai():
    reply = None
    user_message = ''
    if request.method == 'POST':
        user_message = request.form.get('message','').strip()
        reply = campus_ai_reply(user_message)
    return render_template('campus_ai.html', reply=reply, user_message=user_message)


@app.route('/transport')
@login_required
def transport():
    return render_template('transport.html')


@app.route('/upload-ticket-attachment', methods=['POST'])
@login_required
def upload_ticket_attachment():
    """Upload an attachment to a ticket"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    ticket_id = request.form.get('ticket_id')
    
    if not ticket_id:
        return jsonify({'error': 'No ticket ID provided'}), 400
    
    try:
        ticket_id = int(ticket_id)
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid ticket ID'}), 400
    
    # Check if ticket exists and user has access
    ticket = next((t for t in current_tickets() if t['id'] == ticket_id), None)
    if not ticket:
        return jsonify({'error': 'Ticket not found'}), 404
    
    username = session.get('user')
    user_role = session.get('role')
    
    # Check access: ticket owner, assigned staff, or admin
    if ticket['username'] != username and ticket['assigned_to'] != username and user_role not in ['admin', 'owner', 'it']:
        return jsonify({'error': 'Access denied'}), 403
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': f'File type not allowed. Allowed: {", ".join(ALLOWED_EXTENSIONS)}'}), 400
    
    # Check file size
    file.seek(0, os.SEEK_END)
    file_size = file.tell()
    file.seek(0)
    
    if file_size > MAX_FILE_SIZE:
        return jsonify({'error': f'File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB'}), 400
    
    # Save file
    secure_name = secure_filename_with_uuid(file.filename)
    file_path = os.path.join(UPLOAD_DIR, secure_name)
    file.save(file_path)
    
    # Add to database
    attachment_id = add_ticket_attachment(ticket_id, file.filename, file_path, username)
    ticket.setdefault('attachments', []).append({
        'id': attachment_id,
        'filename': file.filename,
        'file_path': file_path,
        'uploaded_by': username,
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M')
    })
    
    return jsonify({'success': True, 'attachment_id': attachment_id, 'filename': file.filename}), 201


@app.route('/upload-comment-attachment', methods=['POST'])
@login_required
def upload_comment_attachment():
    """Upload an attachment to a comment"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    comment_id = request.form.get('comment_id')
    
    if not comment_id:
        return jsonify({'error': 'No comment ID provided'}), 400
    
    try:
        comment_id = int(comment_id)
    except (ValueError, TypeError):
        return jsonify({'error': 'Invalid comment ID'}), 400
    
    # Check if comment exists
    comment = query_db('SELECT * FROM ticket_comments WHERE id = %s', (comment_id,), one=True)
    if not comment:
        return jsonify({'error': 'Comment not found'}), 404
    
    comment = dict(comment)
    ticket_id = comment['ticket_id']
    
    # Check if user has access to the ticket
    ticket = next((t for t in current_tickets() if t['id'] == ticket_id), None)
    if not ticket:
        return jsonify({'error': 'Ticket not found'}), 404
    
    username = session.get('user')
    user_role = session.get('role')
    
    # Check access: comment author, ticket owner, assigned staff, or admin
    if comment['author'] != username and ticket['username'] != username and ticket['assigned_to'] != username and user_role not in ['admin', 'owner', 'it']:
        return jsonify({'error': 'Access denied'}), 403
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': f'File type not allowed. Allowed: {", ".join(ALLOWED_EXTENSIONS)}'}), 400
    
    # Check file size
    file.seek(0, os.SEEK_END)
    file_size = file.tell()
    file.seek(0)
    
    if file_size > MAX_FILE_SIZE:
        return jsonify({'error': f'File too large. Maximum size is {MAX_FILE_SIZE // (1024*1024)}MB'}), 400
    
    # Save file
    secure_name = secure_filename_with_uuid(file.filename)
    file_path = os.path.join(UPLOAD_DIR, secure_name)
    file.save(file_path)
    
    # Add to database
    attachment_id = add_comment_attachment(comment_id, file.filename, file_path, username)
    
    return jsonify({'success': True, 'attachment_id': attachment_id, 'filename': file.filename}), 201


@app.route('/preview-attachment/<int:attachment_id>')
@login_required
def preview_attachment(attachment_id):
    attachment = get_attachment_by_id(attachment_id)
    if not attachment or not os.path.exists(attachment['file_path']):
        return 'Attachment not found', 404
    return send_file(attachment['file_path'], mimetype=mimetypes.guess_type(attachment['filename'])[0], as_attachment=False)


@app.route('/download-attachment/<int:attachment_id>')
@login_required
def download_attachment(attachment_id):
    """Download a ticket attachment with access control"""
    attachment = get_attachment_by_id(attachment_id)
    if not attachment:
        return 'Attachment not found', 404
    
    # Check access
    ticket = next((t for t in current_tickets() if t['id'] == attachment['ticket_id']), None)
    if not ticket:
        return 'Ticket not found', 404
    
    username = session.get('user')
    user_role = session.get('role')
    
    # Check access: ticket owner, assigned staff, or admin
    if ticket['username'] != username and ticket['assigned_to'] != username and user_role not in ['admin', 'owner', 'it']:
        return 'Access denied', 403
    
    if not os.path.exists(attachment['file_path']):
        return 'File not found', 404
    
    try:
        return send_file(
            attachment['file_path'],
            as_attachment=True,
            download_name=attachment['filename']
        )
    except Exception as e:
        return f'Error downloading file: {str(e)}', 500


@app.route('/delete-attachment/<int:attachment_id>', methods=['POST'])
@login_required
def delete_attachment_route(attachment_id):
    """Delete an attachment with access control"""
    attachment = get_attachment_by_id(attachment_id)
    if not attachment:
        return jsonify({'error': 'Attachment not found'}), 404
    
    # Check access
    ticket = next((t for t in current_tickets() if t['id'] == attachment['ticket_id']), None)
    if not ticket:
        return jsonify({'error': 'Ticket not found'}), 404
    
    username = session.get('user')
    user_role = session.get('role')
    
    # Check access: uploader, ticket owner, or admin
    if attachment['uploaded_by'] != username and ticket['username'] != username and user_role not in ['admin', 'owner', 'it']:
        return jsonify({'error': 'Access denied'}), 403
    
    # Delete from database and filesystem
    delete_attachment(attachment_id)
    
    # Refresh happens automatically because tickets are loaded from the database.
    if 'attachments' in ticket:
        ticket['attachments'] = [a for a in ticket['attachments'] if a.get('id') != attachment_id]
    
    return jsonify({'success': True}), 200


@app.route('/delete-comment-attachment/<int:attachment_id>', methods=['POST'])
@login_required
def delete_comment_attachment_route(attachment_id):
    """Delete a comment attachment with access control"""
    attachment = get_comment_attachment_by_id(attachment_id)
    if not attachment:
        return jsonify({'error': 'Attachment not found'}), 404
    
    # Check access
    comment = query_db('SELECT * FROM ticket_comments WHERE id = %s', (attachment['comment_id'],), one=True)
    if not comment:
        return jsonify({'error': 'Comment not found'}), 404
    
    comment = dict(comment)
    ticket_id = comment['ticket_id']
    ticket = next((t for t in current_tickets() if t['id'] == ticket_id), None)
    if not ticket:
        return jsonify({'error': 'Ticket not found'}), 404
    
    username = session.get('user')
    user_role = session.get('role')
    
    # Check access: uploader, comment author, ticket owner, or admin
    if attachment['uploaded_by'] != username and comment['author'] != username and ticket['username'] != username and user_role not in ['admin', 'owner', 'it']:
        return jsonify({'error': 'Access denied'}), 403
    
    # Delete from database and filesystem
    delete_comment_attachment(attachment_id)
    
    return jsonify({'success': True}), 200

if __name__ == "__main__":
    try:
        with app.app_context():
            init_db()
        print("=" * 50)
        print("MYSQL DATABASE CONNECTED SUCCESSFULLY")
        print(f"HOST: {os.getenv('MYSQL_HOST')}")
        print(f"PORT: {os.getenv('MYSQL_PORT')}")
        print(f"DATABASE: {os.getenv('MYSQL_DATABASE')}")
        print("=" * 50)
    except Exception as e:
        print("=" * 50)
        print("MYSQL CONNECTION FAILED")
        print(str(e))
        print("=" * 50)

    host = os.getenv("APP_HOST", "0.0.0.0")
    port = int(os.getenv("APP_PORT", "5000"))
    debug = env_bool("FLASK_DEBUG", False)

    print(f"Starting server on http://{host}:{port}")
    app.run(host=host, port=port, debug=debug)
