# Smart Campus Service Desk System

## Quick run

### Windows
Double-click `run_windows.bat`.

### macOS / Linux
Run:

```bash
chmod +x run_linux_mac.sh
./run_linux_mac.sh
```

Then open `http://127.0.0.1:5000`.

Default logins:

- `admin` / `ChangeMeAdmin123!`
- `user` / `ChangeMeUser123!`

See `HOW_TO_RUN.md` for more details.

---

# Smart Campus Service Desk System — Milestone 1

## Overview

This repository contains a Flask-based service desk system prototype for Milestone 1. The application demonstrates a secure login workflow, session management, and role-based access control for admin and regular user dashboards.

## Project Structure

```
smart-campus-service-desk-system-main/
├── app.py                          # Flask application entry point
├── requirements.txt                # Python dependencies
├── README.md                       # Project documentation
├── templates/                      # HTML templates
│   ├── base.html                   # Site layout and navigation
│   ├── login.html                  # Login form
│   ├── user/
│   │   └── dashboard.html          # User dashboard view
│   └── admin/
│       └── dashboard.html          # Admin dashboard view
└── static/
    └── style.css                  # Custom stylesheet
```

## Key Features

- **Hardcoded authentication** for initial milestone delivery
- **Session-based login** with secure session management
- **Role-based redirects** for admin and user portals
- **Route protection** via reusable decorators
- **Responsive UI** with Bootstrap and custom styles

## User Accounts

For demonstration and testing purposes, the following credentials are available:

- Admin: `admin` / `admin123`
- User: `user` / `user123`

## Supported Routes

- `GET /` — Home page
- `GET /login` — Display login form
- `POST /login` — Authenticate user credentials
- `GET /logout` — Terminate session and redirect to login
- `GET /user/dashboard` — Protected user dashboard
- `GET /admin/dashboard` — Protected admin dashboard

## Prerequisites

- Python 3.11+ recommended
- Virtual environment support (`venv`)
- PowerShell or Command Prompt on Windows
- Basic terminal access on macOS/Linux

## Installation and Setup

1. Open a terminal and verify your Python version:

```bash
python --version
```

2. Upgrade `pip` before installing dependencies:

```bash
python -m pip install --upgrade pip
```

3. Create a virtual environment in the project root:

```bash
python -m venv .venv
```

4. Activate the virtual environment:

**Windows (PowerShell):**

```powershell
.\.venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**

```cmd
.venv\Scripts\activate.bat
```

**macOS/Linux:**

```bash
source .venv/bin/activate
```

5. Install the project dependencies:

```bash
pip install -r requirements.txt
```

6. Confirm dependencies were installed successfully:

```bash
pip list
```

You should see `Flask`, `Werkzeug`, `Jinja2`, and related packages listed.

## Configuration

This application is configured for local development. Before using it in a shared environment, update the secret key in `app.py`:

```python
app.secret_key = 'your-secret-key-change-this-in-production'
```

For a more secure setup, use an environment variable instead of a hardcoded key.

## MySQL Configuration

Set the following environment variables before starting the app if you want to use MySQL instead of SQLite:

```powershell
$env:MYSQL_HOST = 'localhost'
$env:MYSQL_PORT = '3306'
$env:MYSQL_USER = 'root'
$env:MYSQL_PASSWORD = 'your_password'
$env:MYSQL_DATABASE = 'smartcampus'
```

The app will automatically create the database and required tables if they do not exist.

## Running the Application

With the virtual environment active, start the app:

```bash
python app.py
```

Alternatively, you can use Flask's built-in runner:

```bash
set FLASK_APP=app.py
set FLASK_ENV=development
flask run
```

or on macOS/Linux:

```bash
export FLASK_APP=app.py
export FLASK_ENV=development
flask run
```

Then open the application in your browser:

```text
http://localhost:5000
```

## Troubleshooting

- If `python` is not found, make sure Python is installed and on your system PATH.
- If activation fails, verify the path to `.venv/Scripts` or `.venv/bin`.
- If package installation fails, try:

```bash
python -m pip install -r requirements.txt
```

- If you see a `ModuleNotFoundError`, ensure the virtual environment is activated.

## Notes

- The application uses a hardcoded `app.secret_key`; replace this with a strong secret before deploying to production.
- This version is intended for Milestone 1 and does not include persistent user storage or database integration.

## Role-Based Feature Ideas

### 1. User Role (Students/Staff)
**Service Request Workflow**
- Priority selection (Urgent, High, Normal, Low)
- Category templates (IT Support, Facilities, Academic, Other)
- Attachment support for screenshots/documents
- Request scheduling (immediate vs. scheduled appointment)
- Auto-categorization based on keywords

**Ticket Management**
- Submit and track tickets
- View their own ticket history and status
- Add comments or attachments to requests
- See FAQ / knowledge base suggestions
- Receive notifications when ticket status changes
- Real-time status updates and notifications
- Estimated resolution time display
- Similar tickets suggestions
- Request history with search/filter
- Print ticket summary

**Communication**
- In-app chat with support staff
- Email notifications for status changes
- Feedback rating system (1-5 stars)
- Issue survey after resolution
- User-to-user messaging inbox and sent message support

### 2. IT Role (Technical Support)
**Ticket Management**
- View all technical tickets in a dedicated queue
- Technical queue with SLA timers
- Priority-based sorting
- Bulk actions (assign, status update, close)
- Filter by priority, category, or assigned technician
- Assign tickets to themselves or other IT staff
- Remote support session links
- Hardware/software asset tracking
- Knowledge base article suggestions

**Knowledge Management**
- Common solutions templates
- Troubleshooting step library
- Link tickets to knowledge base
- Create internal wiki/documentation
- Add internal notes and resolution steps
- Mark tickets as "In Progress", "Resolved", or "Closed"

**Performance Tracking**
- Average resolution time
- Tickets closed this week/month
- Top issue categories
- Personal performance metrics

### 3. Staff Role (Administrative Support)
**Facilities & Resources**
- Access campus support tickets for general facilities or services
- Request help for meeting rooms, equipment, or admin support
- Track non-technical requests and status updates
- See a simplified dashboard of open/assigned tickets
- Room/equipment availability calendar
- Booking system integration
- Maintenance request workflow
- Supply ordering system
- Facilities inspection checklists

**Department Coordination**
- Collaborate with IT or teacher roles on cross-department issues
- Cross-department ticket routing
- Department-level dashboards
- Staff schedule management
- Work assignment distribution

### 4. Teacher Role (Educators)
**Service Requests**
- Submit classroom, lab, or course-related service requests
- Track student-facing tech issues and facility needs
- Request special equipment or training support
- View announcements or system maintenance schedules
- Approve student account requests if needed

**Enhanced Grading System**
- Gradebook with class roster
- Batch grade imports (CSV)
- Grade distribution analytics
- Class performance reports
- Letter grade/percentage conversion

**Course Management**
- Student roster management
- Course materials repository
- Assignment submission tracking
- Attendance records
- Class announcements/notices

**Academic Support**
- Student performance alerts
- Academic calendar integration
- Grade dispute/appeal workflow
- Parent/guardian notifications

### 5. Admin Role
**System Management**
- User role assignment/revocation
- Department management
- Account activation/deactivation
- Password reset tools
- User import/export (CSV/Excel)

**Content Management**
- Manage FAQ/knowledge base articles
- Category and priority customization
- System announcements
- Help documentation editing

**Monitoring**
- System activity logs
- User login history
- Failed authentication attempts
- File upload/deletion history

### 6. Owner Role (Executive)
**Analytics & Reporting**
- Full admin overview of the system
- Manage users, roles, and pending approvals
- Dashboard with key metrics
- Ticket volume trends (weekly/monthly)
- Average response/resolution times
- Department performance comparison
- Cost analysis per department
- SLA compliance rates

**Strategic Management**
- View analytics: ticket volume, response times, open vs closed
- Configure categories, priorities, and workflows
- System configuration and settings
- Role and permission management
- Automated escalation rules
- Backup and restore functions
- System health monitoring
- API key management

**Audit & Compliance**
- Audit logs and system settings
- Complete audit trails
- Export reports (PDF, Excel)
- Data retention policies
- Access control logs
- Compliance reports

### Cross-Cutting Features (All Roles)
**Notification System**
- In-app notifications
- Email digest options
- SMS alerts for urgent items
- Notification preferences
- Do-not-disturb schedules

**Search & Filtering**
- Full-text search across tickets
- Advanced filters (date, status, assignee, priority)
- Saved searches
- Search history

**Mobile Support**
- Responsive mobile interface
- Native mobile app (optional)
- Mobile notifications
- Offline mode with sync

**Integration Opportunities**
- Calendar integration (Google Calendar, Outlook)
- Email-to-ticket conversion
- Slack/Teams notifications
- Zapier/IFTTT automation
- CRM system integration

**Accessibility & Localization**
- Dark mode support
- High contrast theme
- Keyboard navigation
- Multi-language support
- Accessibility compliance (WCAG 2.1)

### Idea Summary
- Give each role a tailored dashboard
- Limit access based on role responsibilities
- Use role-specific filters and actions
- Make "owner" the only role with global management rights

## New Features Added
- Knowledge base page with FAQ articles
- User ticket comments and comment thread display
- Reopen closed tickets from the user dashboard
- Admin internal ticket notes and comment logging
- User contact details management for email, phone, and address
- User-to-user messaging inbox and sent message support
- Ticket export to CSV for reporting
- Pending user account approval flow for administrators
- Teacher grading system with grade assignment and tracking
- Role-specific welcome messages on dashboard
- Dual-database support (SQLite and MySQL)
- Owner role with admin access

## Roadmap and Planned Enhancements
These features are planned for future milestones:
- Saved ticket drafts so users can continue requests later
- Attachments for tickets and messages
- Rich text editing for ticket descriptions and comments
- Real-time chat or live support messaging
- Agent-only internal notes and mention notifications
- Audit trails and SLA response metrics
- Role-based permissions and department routing
- Multi-language support and accessibility improvements
- API access for mobile apps and external systems
- Calendar and email integration for service reminders
- Dedicated dashboards for each role (IT, Staff, Teacher)
- Advanced analytics and reporting dashboards
- Automated ticket routing and escalation
- Third-party integrations and webhooks

## Updated Configuration Notes

This improved version keeps runtime files out of the source folder. Before running in production, copy `.env.example` to `.env` and change `SECRET_KEY` and the default passwords.

Default demo accounts on a fresh database:

- `admin` / `ChangeMeAdmin123!`
- `user` / `ChangeMeUser123!`

For development:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python app.py
```


---

## Planned Features

The following features are planned for future development milestones:

- User authentication with role-based access
- Ticket priority and SLA tracking
- Email notifications for ticket updates
- Admin dashboard analytics and reporting
- File attachment support for tickets
- Real-time messaging between users and support staff
- AI-powered ticket categorization
- REST API integration
- Docker container deployment
- Multi-language support
- Audit logging and activity tracking
- Password reset via email
- Search and advanced filtering
- Mobile responsive interface
- Department-based ticket routing
- Technician assignment system
- QR-code issue reporting
- Campus map issue localization
- LDAP / University SSO integration
- IoT and Cisco monitoring integration
