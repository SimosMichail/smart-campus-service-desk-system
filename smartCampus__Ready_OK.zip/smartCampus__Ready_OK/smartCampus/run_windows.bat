@echo off
cd /d "%~dp0"

echo ============================================
echo Smart Campus Service Desk - Setup and Run
echo ============================================

where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.10+ and tick "Add Python to PATH".
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate

echo Installing requirements...
python -m pip install --upgrade pip
pip install -r requirements.txt

set DB_TYPE=sqlite
set FLASK_DEBUG=1

echo.
echo Starting app...
echo Open this in your browser: http://127.0.0.1:5000
echo Default admin login: admin / ChangeMeAdmin123!
echo Default user login: user / ChangeMeUser123!
echo.
python app.py

pause
