#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "Smart Campus Service Desk - Setup and Run"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 was not found. Install Python 3.10+ first."
  exit 1
fi

if [ ! -f ".venv/bin/python" ]; then
  echo "Creating virtual environment..."
  python3 -m venv .venv
fi

source .venv/bin/activate

echo "Installing requirements..."
python -m pip install --upgrade pip
pip install -r requirements.txt

export DB_TYPE=sqlite
export FLASK_DEBUG=1

echo "Starting app..."
echo "Open this in your browser: http://127.0.0.1:5000"
echo "Default admin login: admin / ChangeMeAdmin123!"
echo "Default user login: user / ChangeMeUser123!"
python app.py
